# 远控机上的分析环境（2026-09-10）

这个包让远控 Windows 机器能独立完成分析：**ROOT 文件留在 D 盘不动，
只把最后 100 MB 量级的 npz 搬回主力机。** 比搬 2.5 GB 的 ROOT 少 26 倍。

## 一、放到哪

解压到远控机的任意目录，例如 `D:\beisanshe`。目录结构应该是：

```
D:\beisanshe\
    backscatter\      分析库（20 个模块）
    scripts\          脚本
    configs\          配置
    reference\        环境自检用的参照数据
```

依赖（已确认远控机上都有）：`numpy` `scipy` `uproot` `matplotlib`。

## 二、第一步：环境自检（必须先过）

主力机是 Python 3.12，远控机是 3.13，scipy 版本也不同。KDE 与 bootstrap 都走
scipy，先确认换环境后结果不漂移：

```
cd D:\beisanshe
python scripts\check_environment.py
```

四项判据：闭式解自检通过；横向 y FWHM 与已发布的 4.146 mm 差 < 1%；
深度 z FWHM 与 38.317 mm 差 < 1%；bootstrap 95% CI 与 [3.29, 5.01] 差 < 3%。

参照数据是主力机上 `rod_x_depth30_5m_seed24083101/canonical_response/reconstruction.npz`
的副本，279 个 selected_valid 事例。**这一步不过就别在这台机器上出正式数字。**

## 三、第二步：分析一档 GATE 数据

以 stage a 的参照档为例（把路径换成实际的）：

```
cd D:\beisanshe
python -m backscatter analyze ^
    --root "D:\vgate_shared\output\mural_ref_t10_L-15_2m_seed24091012\hits.root" ^
    --truth "D:\vgate_shared\output\mural_ref_t10_L-15_2m_seed24091012\hits_truth_mural.root" ^
    --config configs\mural_void_20260910.json ^
    --out-dir runs\mural_ref_t10_L-15_2m_seed24091012
```

产出 `events.npz` `pairs.npz` `reconstruction.npz` `summary.json`。
**注意这一步不施加探测器响应**，接着必须跑第三步。

## 四、第三步：施加探测器响应

`analyze` 只做到"理想 GATE 事件对"。官方所有已发布数字都是在**施加响应之后**的
`canonical_response` 目录上算的。少这一步深度会偏乐观。

```
python scripts\apply_response_to_analysis.py ^
    --analysis-dir runs\mural_ref_t10_L-15_2m_seed24091012 ^
    --config configs\mural_void_20260910.json
```

输出写到 `runs\...\canonical_response\`，不改动原目录。
响应随机种子固定 24080601，与官方一致。

两档（ref 与 void）都要走完第二、三步。

## 五、第四步：出结论

观测量是"空鼓/参照的重建深度剖面比值台阶"，**不是"在空鼓深度找亏损"**——
理由见 `configs/mural_void_20260910.json` 的 `observables` 段。
这一步的脚本我另外给，因为它是本轮新写的。

## 六、要搬回主力机的东西

每档的 `runs\<run_id>\` 整个目录，约 100 MB：

| 文件 | 约 |
|---|---|
| `events.npz` | 50~60 MB |
| `pairs.npz` | 13~20 MB |
| `reconstruction.npz` | 5~6 MB |
| `canonical_response\pairs.npz` | 19~25 MB |
| `canonical_response\reconstruction.npz` | 5~6 MB |
| `summary.json` `response_analysis.json` | KB 级 |

`hits.root`（每档 1.15 GB）留在 D 盘别动。

## 七、壁画配置和细杆配置的差别

`configs/mural_void_20260910.json` 相对 `transverse_fwhm_5mm_frozen.json`：

* **探测器与判选一字未改**——同一台仪器，只换体模
* `phantom` 换成分层壁画：细泥 5 mm + 粗泥 35 mm + 砂砾岩 100 mm，整体 z ∈ [−140, 0]
* `selection.phantom_truth_volume_contains` 从 `concrete` 改成 `ground`
  （一次匹配 `ground_fine` 与 `ground_coarse` 两层）
* 新增 `phantom.layers` / `phantom.void` / `phantom.layer_sources` 记录层结构与文献出处
* 新增 `observables` 段，写明观测量与四条冻结判据
* 删掉 `sweep_grid` 与 `validation_protocol`（那是细杆横向分辨率验收用的，与本轮无关）

配置已通过 `backscatter.config.validate_config` 校验。
