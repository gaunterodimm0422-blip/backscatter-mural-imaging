# -*- coding: utf-8 -*-
r"""M3 按 D2 能量分辨 15 % 重做分析（不重跑 GATE），2026-09-23。

背景
----
导师确认 D2 能量分辨应为 15 %（原来一直用 12 %）。能量展宽与位置离散都是在分析时对
GATE 理想沉积事后施加的（backscatter/response.py），GATE 宏里没有任何展宽，所以只需：
  1) 对 M3 五个运行目录重新施加响应（D2 15 %，其余与原来逐字相同，响应种子仍是 24080601），
     写到各自的 runs\<RUN_ID>\response_d2f15\，原来的 canonical_response\（12 %）一个字不动；
  2) 用同一个 analyze_mural_edge.py 重做四次边界分析；
  3) 重出成像演示图的 npz 和两份诊断；
  4) 按原来冻结的九条判据重判。
12 % 的结果（outputs\m3_*、outputs\diag_*、outputs\imaging_demo_*）作为冻结记录保留，不覆盖、不并列报告。
判据 9 的三点拟合这里用 json 里的全精度 x_e；12 % 冻结版当时用的是保留两位小数的 x_e（因此 k 为 0.9263，
全精度是 0.9262），这不影响通过与否。
所有新产物都在 outputs\d2f15\ 下。

用法（远控机 Windows，PowerShell，在 D:\beisanshe 下）
----------------------------------------------------
  <python> scripts\redo_d2f15.py run --dry-run    只打印将要执行的命令
  <python> scripts\redo_d2f15.py run              真跑（已有产物的步骤自动跳过，可重复执行）
  <python> scripts\redo_d2f15.py summary          按九条冻结判据重判，写 outputs\d2f15\m3_d2f15_summary.json

  <python> = C:\Users\Administrator\AppData\Local\Programs\Python\Python313\python.exe
"""
from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
import time
from pathlib import Path

RESP = "response_d2f15"
RUNS = {
    "halfvoid": "m3_halfvoid_t20_L-15_4m_seed24091301",
    "ref": "m3_ref_t20_L-15_4m_seed24091302",
    "refnull": "m3_refnull_t20_L-15_4m_seed24091303",
    "x23": "m3_halfvoidx23_t20_L-15_4m_seed24091311",
    "x31": "m3_halfvoidx31_t20_L-15_4m_seed24091312",
}
CFG = {
    "main": "m3_edge_main_d2f15_20260923.json",
    "offset": "m3_edge_offset_d2f15_20260923.json",
    "offset2": "m3_edge_offset2_d2f15_20260923.json",
    "widefov": "m3_edge_main_widefov_d2f15_20260923.json",
}
RESP_CFG = {"halfvoid": "main", "ref": "main", "refnull": "main", "x23": "offset", "x31": "offset2"}
# 边界分析：输出目录名、空鼓档、配置、零假设抽样次数
EDGE = [
    ("m3_edge_result", "halfvoid", "main", 2000),
    ("m3_offset", "x23", "offset", 200),
    ("m3_offset2", "x31", "offset2", 200),
    ("m3_widefov", "halfvoid", "widefov", 0),
]
IMG = [("imaging_demo_m3", "halfvoid", "m3_edge_result", -15.0, "M3 新构型"),
       ("imaging_demo_m3x23", "x23", "m3_offset", -23.0, "M3 边界离轴 -8 mm"),
       ("imaging_demo_m3x31", "x31", "m3_offset2", -31.0, "M3 边界离轴 -16 mm")]

# ---------------------------------------------------------------- 冻结判据常量（与 M3 冻结值逐字相同）
T_THR = 30.0
XE_TOL = 10.0
CROSS_TOL = 5.0
C_MIN = {(15, 25): 0.319, (25, 35): 0.263}
RATE_RANGE = (15565.0, 25942.0)          # configs 里 frozen_criteria 原文
OMEGA_OVER_4PI = 1.1363 / (4 * math.pi)
M2_PER_ANNIH = 19821.5e-6 * 1.8403 / (4 * math.pi)   # M2 为 12 % 口径，未重做
FOV_B0 = 16.5
FOV_B3 = 34.5
K_PRED, K_TOL, B_TOL, R2_MIN = 0.844, 0.09, 1.0, 0.98
# 12 % 冻结版的判定结果，只用来标记"判定是否翻转"，不输出 12 % 的数
FROZEN_VERDICT = {"1": True, "2": True, "3": True, "4": True, "5": True,
                  "6a": False, "6b": True, "7": False, "8a": True, "8b": False, "9": True}


def P(repo: Path, *parts) -> Path:
    return repo.joinpath(*parts)


def resp_dir(repo, key):
    return P(repo, "runs", RUNS[key], RESP)


def out_root(repo):
    return P(repo, "outputs", "d2f15")


def _q(a: str) -> str:
    return f'"{a}"' if " " in a else a


def _edge_json(repo, name):
    f = out_root(repo) / name / "m2_edge_result.json"
    return json.loads(f.read_text(encoding="utf-8")) if f.exists() else None


# ---------------------------------------------------------------- run
def run(args) -> int:
    repo, py = args.repo, sys.executable
    missing = []
    for k, rid in RUNS.items():
        if not P(repo, "runs", rid, "pairs.npz").exists():
            missing.append(f"找不到 {P(repo, 'runs', rid, 'pairs.npz')}")
    for c in CFG.values():
        if not P(repo, "configs", c).exists():
            missing.append(f"找不到配置 {P(repo, 'configs', c)}")
    for s in ("apply_response_to_analysis.py", "analyze_mural_edge.py",
              "make_imaging_demo.py", "diag_multiscatter.py", "diag_shallow_band.py"):
        if not P(repo, "scripts", s).exists():
            missing.append(f"找不到脚本 {P(repo, 'scripts', s)}")
    if missing:
        print("\n".join("  !! " + m for m in missing))
        if not args.dry_run:
            print("先把缺的补齐。")
            return 1

    only = {s.strip() for s in args.only.split(",") if s.strip()} or {"response", "edge", "extras"}
    print(f"仓库   : {repo}\nPython : {py}\n阶段   : {sorted(only)}\n"
          f"模式   : {'只打印命令（--dry-run）' if args.dry_run else '真跑'}\n")

    steps = []
    if "response" in only:
        for k in RUNS:
            steps.append((f"响应 D2 15 %  {k:9s}", resp_dir(repo, k) / "reconstruction.npz",
                          [py, str(P(repo, "scripts", "apply_response_to_analysis.py")),
                           "--analysis-dir", str(P(repo, "runs", RUNS[k])),
                           "--config", str(P(repo, "configs", CFG[RESP_CFG[k]])),
                           "--out-dir", str(resp_dir(repo, k))]))
    if "edge" in only:
        for name, hv, cfg, trials in EDGE:
            steps.append((f"边界分析 {name}（零假设 {trials} 次）",
                          out_root(repo) / name / "m2_edge_result.json",
                          [py, str(P(repo, "scripts", "analyze_mural_edge.py")),
                           "--halfvoid", str(resp_dir(repo, hv)),
                           "--ref-main", str(resp_dir(repo, "ref")),
                           "--ref-null", str(resp_dir(repo, "refnull")),
                           "--config", str(P(repo, "configs", CFG[cfg])),
                           "--out", str(out_root(repo) / name),
                           "--null-trials", str(trials)]))
    if "extras" in only:
        for name, hv, src, truth, label in IMG:
            steps.append((f"成像 npz {name}", out_root(repo) / name / "imaging_demo_data.npz",
                          ("IMG", name, hv, src, truth, label)))
        steps.append(("诊断 diag_ms_m3（按散射次数拆对比度）",
                      out_root(repo) / "diag_ms_m3" / "diag_multiscatter.json",
                      [py, str(P(repo, "scripts", "diag_multiscatter.py")),
                       "--ref", str(resp_dir(repo, "ref")), "--void", str(resp_dir(repo, "halfvoid")),
                       "--config", str(P(repo, "configs", CFG["main"])),
                       "--label", "M3 D2 15%", "--out", str(out_root(repo) / "diag_ms_m3")]))
        steps.append(("诊断 diag_m3_ref（杠杆臂与深度误差）",
                      out_root(repo) / "diag_m3_ref" / "diag_shallow_band.json",
                      [py, str(P(repo, "scripts", "diag_shallow_band.py")),
                       "--analysis-dir", str(resp_dir(repo, "ref")),
                       "--config", str(P(repo, "configs", CFG["main"])),
                       "--label", "M3 D2 15%", "--out", str(out_root(repo) / "diag_m3_ref")]))

    for name, product, cmd in steps:
        if product.exists():
            print(f"[跳过] {name}：已有 {product.name}")
            continue
        if isinstance(cmd, tuple) and cmd[0] == "IMG":
            _, oname, hv, src, truth, label = cmd
            d = _edge_json(repo, src)
            if d is None:
                fit_txt = "<等 " + src + " 边界分析做完后自动读取>"
                if not args.dry_run:
                    print(f"  !! {name}：需要先有 {src} 的结果，跳过。")
                    continue
            else:
                fit_txt = f"{float(d['fits']['signal']['xe']) + float(d['head_x_mm']):.2f}"
            cmd = [py, str(P(repo, "scripts", "make_imaging_demo.py")),
                   "--ref", str(resp_dir(repo, "ref")), "--void", str(resp_dir(repo, hv)),
                   "--config", str(P(repo, "configs", CFG["main"])),
                   "--x-edge-truth", f"{truth}", "--x-edge-fit", fit_txt,
                   "--label", label, "--out", str(out_root(repo) / oname)]
        print(f"[{'命令' if args.dry_run else '执行'}] {name}")
        print("    " + " ".join(_q(a) for a in cmd))
        if args.dry_run:
            continue
        t0 = time.time()
        r = subprocess.run(cmd, cwd=str(repo))
        if r.returncode != 0:
            print(f"  !! 这一步失败（返回码 {r.returncode}），停止。把上面的输出发回来。")
            return r.returncode
        print(f"    完成，用时 {time.time() - t0:.0f} s")
    print("\n结束。下一步：scripts\\redo_d2f15.py summary")
    return 0


# ---------------------------------------------------------------- summary
def _fit(d):
    head = float(d["head_x_mm"])
    s, cons, null, split = (d["fits"][k] for k in ("signal", "consistency", "null", "null_split"))
    bands = [tuple(map(int, b)) for b in d["bands_mm"]]
    return dict(T=float(s["T"]), xe_world=float(s["xe"]) + head, xe_head=float(s["xe"]),
                lo=float(s["xe_lo"]) + head, hi=float(s["xe_hi"]) + head,
                truth=float(d["truth_edge_world_mm"]), head=head,
                cross=float(cons["xe"]) - float(s["xe"]),
                c=dict(zip(bands, [float(v) for v in s["c"]])),
                T_null=float(null["T"]), T_split=float(split["T"]),
                inputs=d.get("inputs") or {}, nsel=d.get("n_selected") or {}, npri=d.get("n_primary") or {},
                ncal=d.get("null_calibration") or {})


def summary(args) -> int:
    repo = args.repo
    res = {n: _edge_json(repo, n) for n, *_ in EDGE}
    miss = [n for n, v in res.items() if v is None]
    if miss:
        print(f"缺结果：{miss}。先跑完 run。")
        return 1
    guard = []
    for n, d in res.items():
        for k, v in (d.get("inputs") or {}).items():
            if Path(str(v).replace("\\", "/")).name != RESP:
                guard.append(f"{n} 的 {k} 输入不是 {RESP}：{v}")
    F = {n: _fit(res[n]) for n in ("m3_edge_result", "m3_offset", "m3_offset2")}
    lab = {"m3_edge_result": "轴心 −15", "m3_offset": "离轴 −23", "m3_offset2": "离轴 −31"}
    V, rows = {}, []

    V["1"] = all(f["T"] >= T_THR for f in F.values())
    V["2"] = all(abs(f["xe_world"] - f["truth"]) <= XE_TOL for f in F.values())
    m = F["m3_edge_result"]
    V["3"] = m["T_null"] < T_THR and m["T_split"] < T_THR
    V["4"] = all(abs(f["cross"]) <= CROSS_TOL for f in F.values())
    V["5"] = all(all(c > 0 for c in f["c"].values()) for f in F.values())
    V["6a"] = m["c"][(15, 25)] >= C_MIN[(15, 25)]
    V["6b"] = m["c"][(25, 35)] >= C_MIN[(25, 35)]
    per_m = m["nsel"]["ref_main"] / m["npri"]["ref_main"] * 1e6
    V["7"] = RATE_RANGE[0] <= per_m <= RATE_RANGE[1]
    per_annih = per_m * 1e-6 * OMEGA_OVER_4PI

    w = res["m3_widefov"]
    xc = [float(v) for v in w["x_centres_mm"]]
    win = []
    for row in w["band_mask"]:
        on = [x for x, b in zip(xc, row) if b]
        win.append((min(on), max(on)) if on else (float("nan"), float("nan")))
    V["8a"] = win[0][0] <= -FOV_B0 and win[0][1] >= FOV_B0
    V["8b"] = win[3][0] < -FOV_B3 and win[3][1] > FOV_B3

    pts = [(f["truth"] - f["head"], f["xe_head"]) for f in F.values()]
    n = len(pts); mu = sum(u for u, _ in pts) / n; my = sum(y for _, y in pts) / n
    sxx = sum((u - mu) ** 2 for u, _ in pts); sxy = sum((u - mu) * (y - my) for u, y in pts)
    k = sxy / sxx; b = my - k * mu
    resid = [y - (k * u + b) for u, y in pts]
    ssr = sum(r * r for r in resid); sst = sum((y - my) ** 2 for _, y in pts)
    r2 = 1 - ssr / sst; s2 = ssr / (n - 2)
    sk = math.sqrt(s2 / sxx); sb = math.sqrt(s2 * (1 / n + mu * mu / sxx))
    V["9"] = abs(k - K_PRED) <= K_TOL and abs(b) <= B_TOL and r2 >= R2_MIN

    print("M3 按 D2 能量分辨 15 % 重做：九条冻结判据重判（响应目录 response_d2f15）\n")
    print(f"{'档':<10}{'T':>8}{'x_e(世界)':>11}{'偏差':>8}{'68% 区间':>20}{'半宽':>7}{'交叉差':>8}   c_b(%) 0–8 / 8–15 / 15–25 / 25–35")
    for key, f in F.items():
        cb = " / ".join(f"{100 * f['c'][bd]:.2f}" for bd in sorted(f["c"]))
        print(f"{lab[key]:<10}{f['T']:>8.1f}{f['xe_world']:>11.2f}{f['xe_world'] - f['truth']:>+8.2f}"
              f"{'[' + format(f['lo'], '.3f') + ', ' + format(f['hi'], '.3f') + ']':>20}{(f['hi'] - f['lo']) / 2:>7.3f}"
              f"{f['cross']:>+8.2f}   {cb}")
    nc = m["ncal"]
    print(f"\n零假设 ref_null/ref_main T = {m['T_null']:.1f}（阈值 30，余量 {T_THR - m['T_null']:.1f}）；ref_main 对半 T = {m['T_split']:.1f}")
    if nc:
        print(f"零分布 {nc.get('trials')} 次自举：中位 {nc.get('p50', float('nan')):.1f}，99% {nc.get('p99', float('nan')):.1f}，最大 {nc.get('max', float('nan')):.1f}")
    print(f"ref_main 每百万初级选出 {per_m:.1f}（冻结区间 [{RATE_RANGE[0]:.0f}, {RATE_RANGE[1]:.0f}]）；"
          f"每真实湮没选出率 {per_annih:.4e}（对 M2 之比 {per_annih / M2_PER_ANNIH:.3f}，M2 未按 15 % 重做）")
    print("有效窗（widefov，探测头坐标，箱中心）：" + "；".join(
        f"{a}–{bb} mm [{lo:+.1f}, {hi:+.1f}]" for (a, bb), (lo, hi) in zip([(0, 8), (8, 15), (15, 25), (25, 35)], win)))
    print(f"三点标定：k = {k:.4f} ± {sk:.4f}，b = {b:+.3f} ± {sb:.3f} mm，r² = {r2:.5f}，残差 "
          + " / ".join(f"{r:+.3f}" for r in resid) + " mm")

    names = {"1": "T ≥ 30（三档）", "2": "|偏差| ≤ 10 mm（三档）", "3": "零假设 T 与对半 T 都 < 30",
             "4": "交叉差 ≤ 5 mm（三档）", "5": "四带 c_b 全正（三档）", "6a": "c_b(15–25) ≥ 31.9 %",
             "6b": "c_b(25–35) ≥ 26.3 %", "7": "每百万初级选出落在冻结区间",
             "8a": "0–8 带有效窗 ≥ ±16.5 mm", "8b": "25–35 带有效窗 > ±34.5 mm",
             "9": "|k − 0.844| ≤ 0.09、|b| ≤ 1、r² ≥ 0.98"}
    print("\n判据            结果    与冻结版判定")
    flips = []
    for key in names:
        same = V[key] == FROZEN_VERDICT[key]
        if not same:
            flips.append(key)
        print(f"  {key:<4} {names[key]:<30} {'通过' if V[key] else '不通过':<6} {'相同' if same else '!! 翻转'}")
    if flips:
        print(f"\n!! 有判据的通过/不通过与 12 % 冻结版不同：{flips}。把这张表原样发回来。")
    if guard:
        print("\n!! 输入核对不通过：\n   " + "\n   ".join(guard))

    out = dict(generated=time.strftime("%Y-%m-%d %H:%M:%S"), response_dir=RESP, d2_fwhm_fraction_at_511=0.15,
               fits={kk: {x: (v if not isinstance(v, dict) or x != "c" else {f"{a}-{bb}": c for (a, bb), c in v.items()})
                          for x, v in f.items() if x not in ("inputs", "nsel", "npri", "ncal")} for kk, f in F.items()},
               null_calibration=nc, per_million_ref_main=per_m, per_real_annihilation=per_annih,
               fov_windows_head_mm={f"{a}-{bb}": list(wv) for (a, bb), wv in zip([(0, 8), (8, 15), (15, 25), (25, 35)], win)},
               calibration=dict(k=k, k_sigma=sk, b=b, b_sigma=sb, r2=r2, residuals=resid, points=pts),
               verdicts=V, verdict_flips_vs_frozen=flips, input_guard_failures=guard)
    od = out_root(repo)
    od.mkdir(parents=True, exist_ok=True)
    (od / "m3_d2f15_summary.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n写出 {od / 'm3_d2f15_summary.json'}")
    return 0


def main() -> int:
    here = Path(__file__).resolve().parents[1]
    ap = argparse.ArgumentParser(description="M3 按 D2 15 % 重做分析（不重跑 GATE）")
    ap.add_argument("--repo", type=Path, default=here)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p1 = sub.add_parser("run")
    p1.add_argument("--dry-run", action="store_true")
    p1.add_argument("--only", default="", help="response,edge,extras 中的若干个，逗号分隔；默认全部")
    sub.add_parser("summary")
    a = ap.parse_args()
    return run(a) if a.cmd == "run" else summary(a)


if __name__ == "__main__":
    sys.exit(main())
