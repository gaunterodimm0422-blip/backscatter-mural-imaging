// ===========================================================================
//  TestPhysicsCore.cpp
//
//  物理内核自检，不依赖 ROOT。做三件事：
//    自检 1  圆锥面解法 与 闭式解法 是否逐事例给出同一个顶点
//    自检 2  与已验证的 Python 参考实现（backscatter.kinematics）逐事例对拍
//    自检 3  能量 <-> 散射角 的正反变换是否自洽，以及能量分辨到角度误差的换算表
//
//  编译：g++ -std=c++17 -O2 -I../src TestPhysicsCore.cpp ../src/ComptonKinematics.cpp -o test_core
// ===========================================================================
#include "ComptonKinematics.h"

#include <cmath>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

using namespace backscatter;

namespace {

struct ReferenceRow {
    Vector3 source, tagging_hit, backscatter_hit;
    double energy_keV = 0.0;
    bool   python_valid = false;
    Vector3 python_vertex;
};

std::vector<ReferenceRow> LoadReferenceVectors(const std::string& path, bool* ok) {
    std::vector<ReferenceRow> rows;
    std::ifstream in(path);
    *ok = in.good();
    if (!*ok) return rows;
    std::string line;
    while (std::getline(in, line)) {
        if (line.empty() || line[0] == '#') continue;
        std::istringstream ss(line);
        ReferenceRow r;
        int valid_flag = 0;
        std::string px, py, pz;
        ss >> r.source.x >> r.source.y >> r.source.z
           >> r.tagging_hit.x >> r.tagging_hit.y >> r.tagging_hit.z
           >> r.backscatter_hit.x >> r.backscatter_hit.y >> r.backscatter_hit.z
           >> r.energy_keV >> valid_flag >> px >> py >> pz;
        r.python_valid = (valid_flag != 0);
        if (r.python_valid) {
            r.python_vertex = {std::stod(px), std::stod(py), std::stod(pz)};
        }
        rows.push_back(r);
    }
    return rows;
}

int failures = 0;
void Check(bool condition, const char* what, const std::string& detail = "") {
    std::printf("  [%s] %s%s%s\n", condition ? "通过" : "不通过", what,
                detail.empty() ? "" : "   ", detail.c_str());
    if (!condition) ++failures;
}

}  // namespace

int main(int argc, char** argv) {
    const std::string reference_path =
        (argc > 1) ? argv[1] : "reference_vectors.txt";

    GeometryConfig geometry;                 // 默认：物体 z ∈ [-140, 0]
    const bool require_inside = true;

    std::printf("==========================================================\n");
    std::printf("物理内核自检\n");
    std::printf("==========================================================\n");

    // ------------------------------------------------------------------
    // 自检 3：能量 <-> 角度 的正反变换，以及能量分辨到角度误差的换算
    // ------------------------------------------------------------------
    std::printf("\n[自检 3] 能量与散射角的正反变换\n");
    double worst_round_trip_deg = 0.0;
    for (int deg = 10; deg <= 175; deg += 5) {
        const double theta = deg * M_PI / 180.0;
        const double e = ScatteredEnergyFromScatterAngle(theta);
        const ScatterAngleResult back = ScatterAngleFromScatteredEnergy(e);
        if (!back.is_valid) { worst_round_trip_deg = 1.0e9; break; }
        worst_round_trip_deg =
            std::max(worst_round_trip_deg, std::fabs(back.theta_rad - theta) * 180.0 / M_PI);
    }
    Check(worst_round_trip_deg < 1.0e-9, "正反变换自洽",
          "最大往返误差 " + std::to_string(worst_round_trip_deg) + " 度");

    std::printf("\n  能量分辨换算成角度误差（背散射探测器 8%% FWHM @511 keV）\n");
    std::printf("  %8s %10s %14s %12s %10s\n",
                "theta", "E'/keV", "dE'/dtheta", "sigma(E')", "sigma(theta)");
    for (int deg : {90, 110, 130, 150, 165}) {
        const double theta = deg * M_PI / 180.0;
        const double e = ScatteredEnergyFromScatterAngle(theta);
        const double h = 1.0e-5;
        const double slope_per_deg =
            std::fabs(ScatteredEnergyFromScatterAngle(theta + h) -
                      ScatteredEnergyFromScatterAngle(theta - h)) / (2.0 * h) * M_PI / 180.0;
        const double fwhm = 0.08 * kAnnihilationPhotonEnergyKeV *
                            std::sqrt(e / kAnnihilationPhotonEnergyKeV);
        const double sigma_e = fwhm / 2.355;
        std::printf("  %6d度 %10.1f %11.2f keV/度 %9.1f keV %8.1f 度\n",
                    deg, e, slope_per_deg, sigma_e, sigma_e / slope_per_deg);
    }
    std::printf("  说明：越接近 180 度，能量对角度越不敏感，角度误差越大。\n"
                "        这是深度分辨远差于横向分辨的根源。\n");

    // ------------------------------------------------------------------
    // 自检 1 与 2
    // ------------------------------------------------------------------
    bool loaded = false;
    const std::vector<ReferenceRow> rows = LoadReferenceVectors(reference_path, &loaded);
    if (!loaded) {
        std::printf("\n找不到参考向量文件 %s，跳过自检 1、2。\n", reference_path.c_str());
        return failures == 0 ? 0 : 1;
    }

    int n_both_valid = 0, n_cone_only = 0, n_closed_only = 0;
    double max_two_method_diff_mm = 0.0;
    int n_agree_with_python = 0, n_python_valid = 0, n_valid_flag_mismatch = 0;
    double max_python_diff_mm = 0.0;

    for (const ReferenceRow& r : rows) {
        const Line3D ray = MakeIncidentRayFromTagging(r.source, r.tagging_hit);
        const ScatterAngleResult angle = ScatterAngleFromScatteredEnergy(r.energy_keV);
        const Cone3D cone = angle.is_valid
            ? MakeScatterCone(r.backscatter_hit, ray.direction, angle.theta_rad)
            : Cone3D{};
        const ScatterVertexResult by_cone =
            IntersectLineWithCone(ray, cone, geometry, require_inside);
        const ScatterVertexResult by_closed_form =
            SolveScatterVertexClosedForm(r.source, r.tagging_hit, r.backscatter_hit,
                                         r.energy_keV, geometry, require_inside);

        if (by_cone.is_valid && by_closed_form.is_valid) {
            ++n_both_valid;
            max_two_method_diff_mm =
                std::max(max_two_method_diff_mm, Norm(by_cone.position - by_closed_form.position));
        } else if (by_cone.is_valid) ++n_cone_only;
        else if (by_closed_form.is_valid) ++n_closed_only;

        if (r.python_valid) ++n_python_valid;
        // Python 参考实现不施加"顶点必须在物体内"这一条，所以只比较它判为有效的事例，
        // 且只要求 C++ 在同样条件下解出同一个点。
        const ScatterVertexResult unconstrained =
            SolveScatterVertexClosedForm(r.source, r.tagging_hit, r.backscatter_hit,
                                         r.energy_keV, geometry, /*require_inside=*/false);
        if (r.python_valid != unconstrained.is_valid) ++n_valid_flag_mismatch;
        if (r.python_valid && unconstrained.is_valid) {
            const double diff = Norm(unconstrained.position - r.python_vertex);
            max_python_diff_mm = std::max(max_python_diff_mm, diff);
            if (diff < 1.0e-9) ++n_agree_with_python;
        }
    }

    std::printf("\n[自检 1] 圆锥面解法 与 闭式解法（%zu 条事例）\n", rows.size());
    std::printf("         两法都有效 %d 条，仅圆锥面有效 %d 条，仅闭式有效 %d 条\n",
                n_both_valid, n_cone_only, n_closed_only);
    Check(n_cone_only == 0 && n_closed_only == 0, "两种解法的有效性判定完全一致");
    Check(max_two_method_diff_mm < 1.0e-6, "两种解法给出同一个顶点",
          "最大差 " + std::to_string(max_two_method_diff_mm) + " mm");

    std::printf("\n[自检 2] 与 Python 参考实现逐事例对拍\n");
    std::printf("         Python 判为有效 %d 条，C++ 同样判为有效并给出相同顶点 %d 条\n",
                n_python_valid, n_agree_with_python);
    Check(n_valid_flag_mismatch == 0, "有效性判定与 Python 完全一致",
          "不一致 " + std::to_string(n_valid_flag_mismatch) + " 条");
    Check(max_python_diff_mm < 1.0e-9, "顶点坐标与 Python 完全一致",
          "最大差 " + std::to_string(max_python_diff_mm) + " mm");

    std::printf("\n==========================================================\n");
    std::printf("%s\n", failures == 0 ? "全部自检通过" : "有自检未通过，见上");
    std::printf("==========================================================\n");
    return failures == 0 ? 0 : 1;
}
