// ===========================================================================
//  ComptonKinematics.h  —— 需求文档第三、四节的全部几何与运动学计算。
//  纯 C++，不依赖 ROOT，便于单独编译测试。
// ===========================================================================
#ifndef COMPTON_KINEMATICS_H
#define COMPTON_KINEMATICS_H

#include "BackscatterAnalysisConfig.h"

namespace backscatter {

// ---------------------------------------------------------------------------
// 三维点/向量
// ---------------------------------------------------------------------------
struct Vector3 {
    double x = 0.0, y = 0.0, z = 0.0;
};
Vector3 operator+(const Vector3& a, const Vector3& b);
Vector3 operator-(const Vector3& a, const Vector3& b);
Vector3 operator*(const Vector3& a, double s);
double  Dot(const Vector3& a, const Vector3& b);
double  Norm(const Vector3& a);
Vector3 Normalize(const Vector3& a);

// ---------------------------------------------------------------------------
// 需求文档 三-1：空间两点之间的直线
//   起点 origin，单位方向 direction，有效长度 length（= 两点距离）
// ---------------------------------------------------------------------------
struct Line3D {
    Vector3 origin;
    Vector3 direction;   // 单位向量
    double  length_mm = 0.0;
    bool    is_valid = false;
};
Line3D MakeLineThroughTwoPoints(const Vector3& from, const Vector3& to);

// 由标记探测器命中点定出射入被检测物体的方向：
// 两个湮没光子严格背靠背，所以入射方向 = 从标记命中点指向源的方向。
Line3D MakeIncidentRayFromTagging(const Vector3& source_position,
                                  const Vector3& tagging_hit_position);

// ---------------------------------------------------------------------------
// 需求文档 三-2：由背散射探测器记录的能量反解康普顿散射角
//
//   E' = E0 / (2 - cos(theta))   =>   cos(theta) = 2 - E0 / E'
//   仅当 E' 落在 [E0/3, E0] 内时 cos(theta) 才在 [-1, 1] 内。
// ---------------------------------------------------------------------------
struct ScatterAngleResult {
    double cos_theta = 0.0;
    double theta_rad = 0.0;
    bool   is_valid = false;
};
ScatterAngleResult ScatterAngleFromScatteredEnergy(
    double scattered_energy_keV,
    double incident_energy_keV = kAnnihilationPhotonEnergyKeV);

// 正向公式，供自检与作图使用
double ScatteredEnergyFromScatterAngle(
    double theta_rad,
    double incident_energy_keV = kAnnihilationPhotonEnergyKeV);

// ---------------------------------------------------------------------------
// 需求文档 三-3：以背散射命中点为顶点、半角为散射角的空间圆锥面
//
//   满足 angle(incident_direction, apex - P) = theta 的点 P 的集合，
//   是一个顶点在 apex、轴沿 -incident_direction、半角为 theta 的圆锥面。
//   散射顶点必落在该面上。
// ---------------------------------------------------------------------------
struct Cone3D {
    Vector3 apex;            // 顶点 = 背散射探测器命中点
    Vector3 axis_direction;  // 单位向量，= -incident_direction
    double  half_angle_rad = 0.0;
    bool    is_valid = false;
};
Cone3D MakeScatterCone(const Vector3& backscatter_hit_position,
                       const Vector3& incident_direction,
                       double theta_rad);

// ---------------------------------------------------------------------------
// 需求文档 三-4 与 四-1：直线与圆锥面求交，并挑出物理的那一个根
//
//   把 P(t) = S + t*v 代入 cos(theta) = v·(X - P) / |X - P| 并平方，得
//       t^2 - 2*a*t + (a^2 - c^2*|d|^2)/(1 - c^2) = 0
//   其中 d = X - S，a = v·d，c = cos(theta)。一般有两个根。
//
//   平方会引入伪根。真根必须同时满足：
//     (1) sign(a - t) == sign(cos theta)      —— 平方前的等式本身
//     (2) t > 0                               —— 顶点在源的下游
//     (3) 顶点落在被检测物体内部（可选，见 SelectionConfig）
// ---------------------------------------------------------------------------
enum class VertexFailureCode {
    kOk = 0,
    kInvalidLine,             // 标记命中点与源重合等
    kUnphysicalEnergy,        // cos(theta) 超出 [-1, 1]
    kDegenerateGeometry,      // sin(theta) ~ 0，圆锥退化成直线
    kNoRealRoot,              // 判别式为负
    kNoRootPassesSignTest,    // 两个根都是伪根
    kVertexBehindSource,      // 唯一的根 t <= 0
    kVertexOutsideObject,     // 顶点不在被检测物体内
    kPathLengthOutOfRange     // 源到顶点的距离超出允许区间
};

struct ScatterVertexResult {
    Vector3 position;                 // 解出的散射顶点
    double  path_length_mm = 0.0;     // 源到顶点的距离 t
    double  theta_rad = 0.0;          // 由能量反解的散射角
    double  alpha_rad = 0.0;          // 源处 入射方向 与 (X - S) 的夹角
    double  root_other_mm = 0.0;      // 另一个根，供诊断
    int     n_roots_passing = 0;      // 通过符号判定的根数
    bool    is_valid = false;
    VertexFailureCode failure = VertexFailureCode::kOk;
};

// 直接解法：直线与圆锥面求交（需求文档的写法）
ScatterVertexResult IntersectLineWithCone(const Line3D& incident_ray,
                                          const Cone3D& scatter_cone,
                                          const GeometryConfig& geometry,
                                          bool require_vertex_inside_object);

// 等价的闭式解法：在三角形 源-顶点-背散射命中点 里用正弦定理，
//   t = |X - S| * sin(theta - alpha) / sin(theta)
// 与上一函数数学等价，但不必构造曲面、不必解二次方程、不必判伪根，
// 数值上更稳。两者在 TestPhysicsCore 里逐事例对拍。
ScatterVertexResult SolveScatterVertexClosedForm(const Vector3& source_position,
                                                 const Vector3& tagging_hit_position,
                                                 const Vector3& backscatter_hit_position,
                                                 double backscatter_energy_keV,
                                                 const GeometryConfig& geometry,
                                                 bool require_vertex_inside_object);

const char* VertexFailureCodeName(VertexFailureCode code);

}  // namespace backscatter
#endif  // COMPTON_KINEMATICS_H
