// ===========================================================================
//  DetectorResponse.h —— 需求文档二-3：位置、能量、时间分辨率。
//  纯 C++，不依赖 ROOT。随机数用固定种子，保证结果可复现。
// ===========================================================================
#ifndef DETECTOR_RESPONSE_H
#define DETECTOR_RESPONSE_H

#include "BackscatterAnalysisConfig.h"
#include "ComptonKinematics.h"

#include <random>

namespace backscatter {

// 能量分辨：FWHM(E) / E 在 511 keV 处等于 fraction_at_511，其余按 sqrt(E) 标度。
//   FWHM(E) = fraction_at_511 * 511 * sqrt(E / 511)
double EnergyResolutionFwhmKeV(double energy_keV, double fwhm_fraction_at_511);
double EnergyResolutionSigmaKeV(double energy_keV, double fwhm_fraction_at_511);

// 把坐标量化到体素中心：origin + (floor((x - origin) / pitch) + 0.5) * pitch
double QuantizeToVoxelCenter(double value_mm, double voxel_size_mm, double origin_mm = 0.0);

struct DetectorResolution {
    double position_x_mm = 1.0;
    double position_y_mm = 1.0;
    double position_z_mm = 2.5;
    double energy_fwhm_fraction_at_511 = 0.15;
    double time_fwhm_ns = 1.0;
};

DetectorResolution TaggingResolution(const DetectorResponseConfig& config);
DetectorResolution BackscatterResolution(const DetectorResponseConfig& config);

// 对一个探测器事件施加响应。原地修改传入的量。
class DetectorResponseApplier {
  public:
    explicit DetectorResponseApplier(const DetectorResponseConfig& config);

    void Apply(const DetectorResolution& resolution,
               Vector3* position, double* energy_keV, double* time_ns);

    void Reset();   // 重置随机数发生器到初始种子

  private:
    DetectorResponseConfig config_;
    std::mt19937_64 generator_;
    std::normal_distribution<double> standard_normal_{0.0, 1.0};
};

}  // namespace backscatter
#endif  // DETECTOR_RESPONSE_H
