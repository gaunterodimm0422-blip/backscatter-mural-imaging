// ===========================================================================
//  RunBackscatterAnalysis.cpp —— 主程序。
//
//  用法
//    ./run_backscatter_analysis <目标文件.root> [参照文件.root] [输出.root]
//
//  只给目标文件：按需求文档一到五跑完整流程，输出直方图与 MLEM 图像。
//  再给参照文件：同一套流程跑两遍，额外输出**比值**（目标/参照）。
//
//  为什么建议总是给参照文件
//  ------------------------
//  参照跑 = 同样几何、同样材料、只把被检测目标挪出视野的一次测量。
//  两者相除时，孔径衰减、探测器不均匀性、源强漂移都精确抵消。
//  没有它，一张 MLEM 图上的任何结构都无法区分是真信号还是重建伪影
//  —— MLEM 本身就会随迭代放大噪声、制造伪结构。
//  另外，把两个**都没有目标**的场跑同一流程（零假设），结果必须是平的；
//  这一步是判断"看到的东西是不是真的"唯一可靠的办法。
// ===========================================================================
#include <cstdio>
#include <memory>
#include <string>
#include <vector>

#include "TFile.h"
#include "TH1D.h"
#include "TH2D.h"

#include "BackscatterAnalysisConfig.h"
#include "ComptonKinematics.h"
#include "DetectorResponse.h"
#include "EventBuilder.h"
#include "HitReader.h"
#include "MlemReconstructor.h"

using namespace backscatter;

namespace {

struct FieldResult {
    std::vector<CoincidencePair> pairs;
    std::vector<SparseRow> rows;
    SelectionCutFlow cut_flow;
    std::size_t n_selected = 0;
};

bool AnalyseOneField(const std::string& file_path, const AnalysisConfig& config,
                     const ImageGrid2D& grid, const char* label, FieldResult* out) {
    std::printf("\n==========================================================\n");
    std::printf("分析 %s：%s\n", label, file_path.c_str());
    std::printf("==========================================================\n");

    const HitReadResult hits = ReadHitsFromRootFile(file_path, config.input);
    if (!hits.ok) { std::printf("读取失败：%s\n", hits.message.c_str()); return false; }
    std::printf("  读入 hit %lld 条：标记探测器 %zu，背散射探测器 %zu\n",
                hits.n_entries_read, hits.tagging_hits.size(), hits.backscatter_hits.size());

    const auto tagging_events = BuildDetectorEvents(
        hits.tagging_hits, config.event_building.tagging_position_mode, config.event_building.time_mode);
    const auto backscatter_events = BuildDetectorEvents(
        hits.backscatter_hits, config.event_building.backscatter_position_mode,
        config.event_building.time_mode);
    std::printf("  合并成探测器事件：标记 %zu，背散射 %zu\n",
                tagging_events.size(), backscatter_events.size());

    DetectorResponseApplier response(config.response);
    bool warned = false;
    out->pairs = BuildAndSelectCoincidences(tagging_events, backscatter_events, config,
                                            &response, &out->cut_flow, &warned);
    out->cut_flow.Print((std::string("判选链条 —— ") + label).c_str());

    for (const CoincidencePair& p : out->pairs) {
        if (!p.passed_selection) continue;
        ++out->n_selected;
        const double distance = Norm(p.backscatter.position - p.tagging.source_position);
        const double sigma = ComputePathSigmaMm(p.vertex, p.backscatter.total_energy_keV, distance,
                                                config.response.backscatter_energy_fwhm_fraction_at_511);
        SparseRow row = BuildSystemMatrixRow(p, grid, sigma);
        if (!row.empty()) out->rows.push_back(std::move(row));
    }
    std::printf("  通过判选 %zu 个事例，投影成系统矩阵 %zu 行\n", out->n_selected, out->rows.size());
    return true;
}

void FillHistograms(const FieldResult& field, const char* suffix, TFile* output,
                    const ImageGrid2D& grid) {
    const std::string s(suffix);
    TH1D h_energy(("backscatter_energy_" + s).c_str(),
                  "背散射探测器沉积能量;能量 (keV);事例数", 200, 100.0, 400.0);
    TH1D h_theta(("scatter_angle_" + s).c_str(),
                 "散射角;theta (度);事例数", 180, 0.0, 180.0);
    TH1D h_depth(("vertex_depth_" + s).c_str(),
                 "重建深度;深度 (mm);事例数", 120, 0.0, 120.0);
    TH2D h_xz(("vertex_x_depth_" + s).c_str(),
              "重建顶点分布;横向 x (mm);深度 (mm)",
              grid.x_bins, grid.x_min_mm, grid.x_max_mm,
              grid.depth_bins, grid.depth_min_mm, grid.depth_max_mm);
    for (const CoincidencePair& p : field.pairs) {
        if (!p.passed_selection) continue;
        h_energy.Fill(p.backscatter.total_energy_keV);
        h_theta.Fill(p.vertex.theta_rad * 180.0 / M_PI);
        h_depth.Fill(-p.vertex.position.z);
        h_xz.Fill(p.vertex.position.x - p.tagging.source_position.x, -p.vertex.position.z);
    }
    output->cd();
    h_energy.Write(); h_theta.Write(); h_depth.Write(); h_xz.Write();
}

TH2D MakeImageHistogram(const std::vector<double>& image, const ImageGrid2D& grid,
                        const char* name, const char* title) {
    TH2D h(name, title, grid.x_bins, grid.x_min_mm, grid.x_max_mm,
           grid.depth_bins, grid.depth_min_mm, grid.depth_max_mm);
    for (int iz = 0; iz < grid.depth_bins; ++iz)
        for (int ix = 0; ix < grid.x_bins; ++ix)
            h.SetBinContent(ix + 1, iz + 1, image[static_cast<std::size_t>(grid.PixelIndex(ix, iz))]);
    return h;
}

void PrintMlemHistory(const MlemResult& result, const char* label) {
    std::printf("\nMLEM —— %s\n", label);
    std::printf("  %6s %20s %22s %20s\n",
                "迭代", "对数似然", "对数似然相对改善", "图像相对变化");
    for (const MlemIterationRecord& r : result.history) {
        const bool show = (r.iteration <= 3) || (r.iteration % 10 == 0) ||
                          (r.iteration == result.iterations_run);
        if (!show) continue;
        std::printf("  %6d %20.6f %22.3e %20.3e\n",
                    r.iteration, r.log_likelihood,
                    r.log_likelihood_relative_change, r.image_relative_change);
    }
    std::printf("  共 %d 次迭代，%s：%s\n", result.iterations_run,
                result.converged ? "已收敛" : "未收敛", result.stop_reason.c_str());
}

}  // namespace

int main(int argc, char** argv) {
    if (argc < 2) {
        std::printf(
            "用法：%s <目标文件.root> [参照文件.root] [输出.root]\n"
            "  只给目标文件时跑单场分析；再给参照文件时额外输出目标/参照的比值。\n"
            "  强烈建议总是给参照文件，理由见本文件顶部注释。\n", argv[0]);
        return 1;
    }
    const std::string target_path = argv[1];
    const std::string reference_path = (argc > 2) ? argv[2] : std::string();
    const std::string output_path = (argc > 3) ? argv[3] : std::string("backscatter_analysis.root");

    AnalysisConfig config;                       // 全部参数见 BackscatterAnalysisConfig.h
    const ImageGrid2D grid = MakeGrid(config.mlem);

    std::unique_ptr<TFile> output(TFile::Open(output_path.c_str(), "RECREATE"));
    if (output == nullptr || output->IsZombie()) {
        std::printf("无法创建输出文件 %s\n", output_path.c_str());
        return 1;
    }

    FieldResult target;
    if (!AnalyseOneField(target_path, config, grid, "目标场", &target)) return 1;
    FillHistograms(target, "target", output.get(), grid);

    FieldResult reference;
    const bool has_reference = !reference_path.empty();
    if (has_reference) {
        if (!AnalyseOneField(reference_path, config, grid, "参照场", &reference)) return 1;
        FillHistograms(reference, "reference", output.get(), grid);
    }

    // ---- MLEM ----
    // 灵敏度：有参照场时用参照场估计（把孔径衰减与探测器不均匀性吸收进去）；
    // 没有参照场时退而用目标场自身估计，此时图像里的结构无法与伪影区分。
    const std::vector<SparseRow>& sensitivity_rows = has_reference ? reference.rows : target.rows;
    if (!has_reference) {
        std::printf("\n  [提醒] 没有给参照场，灵敏度只能用目标场自身估计。\n"
                    "         这种情况下 MLEM 图像里的结构无法与重建伪影区分，\n"
                    "         结果只可用于探路，不可用于下结论。\n");
    }
    const std::vector<double> sensitivity = BuildSensitivityFromReference(
        sensitivity_rows, grid, config.mlem.smoothing_sigma_bins);

    const MlemResult target_image = RunListModeMlem(target.rows, sensitivity, grid, config.mlem);
    PrintMlemHistory(target_image, "目标场");
    output->cd();
    MakeImageHistogram(target_image.image, grid, "mlem_image_target",
                       "MLEM 重建（目标场）;横向 x (mm);深度 (mm)").Write();

    if (has_reference) {
        const MlemResult reference_image =
            RunListModeMlem(reference.rows, sensitivity, grid, config.mlem);
        PrintMlemHistory(reference_image, "参照场");
        output->cd();
        MakeImageHistogram(reference_image.image, grid, "mlem_image_reference",
                           "MLEM 重建（参照场）;横向 x (mm);深度 (mm)").Write();

        std::vector<double> ratio(target_image.image.size(), 1.0);
        for (std::size_t i = 0; i < ratio.size(); ++i) {
            const double denominator = reference_image.image[i];
            ratio[i] = (denominator > 0.0) ? target_image.image[i] / denominator : 0.0;
        }
        MakeImageHistogram(ratio, grid, "mlem_image_ratio",
                           "MLEM 重建比值（目标/参照）;横向 x (mm);深度 (mm)").Write();
        std::printf("\n  已输出比值图 mlem_image_ratio。判读时请记住：\n"
                    "  在没有目标的区域，比值应当处处为 1；如果那里也出现结构，\n"
                    "  说明看到的是伪影，不是信号。\n");
    }

    output->Close();
    std::printf("\n结果写入 %s\n", output_path.c_str());
    return 0;
}
