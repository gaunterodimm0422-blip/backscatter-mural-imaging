#include "MlemReconstructor.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <numeric>

#include "DetectorResponse.h"

namespace backscatter {
namespace {
constexpr double kEpsilon = 1.0e-12;
constexpr double kDegToRad = M_PI / 180.0;
}  // namespace

bool ImageGrid2D::Locate(double x_mm, double depth_mm, int* ix, int* iz) const {
    if (!(x_mm >= x_min_mm && x_mm < x_max_mm)) return false;
    if (!(depth_mm >= depth_min_mm && depth_mm < depth_max_mm)) return false;
    *ix = static_cast<int>((x_mm - x_min_mm) / XBinWidthMm());
    *iz = static_cast<int>((depth_mm - depth_min_mm) / DepthBinWidthMm());
    *ix = std::max(0, std::min(x_bins - 1, *ix));
    *iz = std::max(0, std::min(depth_bins - 1, *iz));
    return true;
}

ImageGrid2D MakeGrid(const MlemConfig& c) {
    ImageGrid2D g;
    g.x_min_mm = c.grid_x_min_mm; g.x_max_mm = c.grid_x_max_mm; g.x_bins = c.grid_x_bins;
    g.depth_min_mm = c.grid_depth_min_mm; g.depth_max_mm = c.grid_depth_max_mm;
    g.depth_bins = c.grid_depth_bins;
    return g;
}

double ComputePathSigmaMm(const ScatterVertexResult& vertex,
                          double backscatter_energy_keV,
                          double source_to_backscatter_distance_mm,
                          double energy_fwhm_fraction_at_511) {
    const double theta = vertex.theta_rad;
    const double sin_theta = std::sin(theta);
    if (!(sin_theta > 1.0e-6)) return 0.0;
    // dE'/dtheta = -E0 sin(theta) / (2 - cos(theta))^2
    const double denominator = 2.0 - std::cos(theta);
    const double d_energy_d_theta =
        kAnnihilationPhotonEnergyKeV * sin_theta / (denominator * denominator);
    if (!(d_energy_d_theta > 1.0e-9)) return 0.0;
    const double sigma_energy =
        EnergyResolutionSigmaKeV(backscatter_energy_keV, energy_fwhm_fraction_at_511);
    const double sigma_theta = sigma_energy / d_energy_d_theta;     // 弧度
    // 顶点沿射线的位移对 theta 的敏感度：t = |d| sin(theta - alpha)/sin(theta)
    // dt/dtheta = |d| [cos(theta-alpha) sin(theta) - sin(theta-alpha) cos(theta)] / sin^2(theta)
    //           = |d| sin(alpha) / sin^2(theta)
    const double dt_d_theta =
        source_to_backscatter_distance_mm * std::sin(vertex.alpha_rad) / (sin_theta * sin_theta);
    return std::fabs(dt_d_theta) * sigma_theta;
}

SparseRow BuildSystemMatrixRow(const CoincidencePair& pair, const ImageGrid2D& grid,
                               double path_sigma_mm, double n_sigma_range) {
    SparseRow row;
    if (!pair.vertex.is_valid) return row;

    const Vector3 source = pair.tagging.source_position;
    const Line3D ray = MakeIncidentRayFromTagging(source, pair.tagging.position);
    if (!ray.is_valid) return row;

    const double t_center = pair.vertex.path_length_mm;
    const double sigma = std::max(path_sigma_mm, 0.5 * grid.DepthBinWidthMm());
    const double t_low  = std::max(0.0, t_center - n_sigma_range * sigma);
    const double t_high = t_center + n_sigma_range * sigma;

    // 沿射线以网格半格步长采样
    const double step = 0.5 * std::min(grid.XBinWidthMm(), grid.DepthBinWidthMm());
    std::vector<double> accumulator(static_cast<std::size_t>(grid.NumPixels()), 0.0);
    bool any = false;
    for (double t = t_low; t <= t_high; t += step) {
        const Vector3 p = ray.origin + ray.direction * t;
        const double depth_mm = -p.z;                // 物体表面 z = 0，深度向下为正
        int ix = 0, iz = 0;
        if (!grid.Locate(p.x - source.x, depth_mm, &ix, &iz)) continue;
        const double u = (t - t_center) / sigma;
        const double weight = std::exp(-0.5 * u * u) * step;
        accumulator[static_cast<std::size_t>(grid.PixelIndex(ix, iz))] += weight;
        any = true;
    }
    if (!any) return row;

    double total = 0.0;
    for (double v : accumulator) total += v;
    if (!(total > 0.0)) return row;
    for (int i = 0; i < grid.NumPixels(); ++i) {
        const double v = accumulator[static_cast<std::size_t>(i)];
        if (v > 0.0) row.emplace_back(i, v / total);   // 行归一：每个事例总权重为 1
    }
    return row;
}

namespace {

void GaussianSmooth2D(std::vector<double>* image, const ImageGrid2D& grid, double sigma_bins) {
    if (!(sigma_bins > 0.0)) return;
    const int radius = std::max(1, static_cast<int>(std::ceil(3.0 * sigma_bins)));
    std::vector<double> kernel(static_cast<std::size_t>(2 * radius + 1));
    double kernel_sum = 0.0;
    for (int k = -radius; k <= radius; ++k) {
        const double w = std::exp(-0.5 * (k / sigma_bins) * (k / sigma_bins));
        kernel[static_cast<std::size_t>(k + radius)] = w;
        kernel_sum += w;
    }
    for (double& w : kernel) w /= kernel_sum;

    std::vector<double> temp(image->size(), 0.0);
    for (int iz = 0; iz < grid.depth_bins; ++iz)
        for (int ix = 0; ix < grid.x_bins; ++ix) {
            double acc = 0.0;
            for (int k = -radius; k <= radius; ++k) {
                const int jx = std::max(0, std::min(grid.x_bins - 1, ix + k));
                acc += kernel[static_cast<std::size_t>(k + radius)] *
                       (*image)[static_cast<std::size_t>(grid.PixelIndex(jx, iz))];
            }
            temp[static_cast<std::size_t>(grid.PixelIndex(ix, iz))] = acc;
        }
    for (int iz = 0; iz < grid.depth_bins; ++iz)
        for (int ix = 0; ix < grid.x_bins; ++ix) {
            double acc = 0.0;
            for (int k = -radius; k <= radius; ++k) {
                const int jz = std::max(0, std::min(grid.depth_bins - 1, iz + k));
                acc += kernel[static_cast<std::size_t>(k + radius)] *
                       temp[static_cast<std::size_t>(grid.PixelIndex(ix, jz))];
            }
            (*image)[static_cast<std::size_t>(grid.PixelIndex(ix, iz))] = acc;
        }
}

}  // namespace

std::vector<double> BuildSensitivityFromReference(const std::vector<SparseRow>& reference_rows,
                                                  const ImageGrid2D& grid,
                                                  double smoothing_sigma_bins,
                                                  double floor_fraction) {
    std::vector<double> sensitivity(static_cast<std::size_t>(grid.NumPixels()), 0.0);
    for (const SparseRow& row : reference_rows)
        for (const auto& [pixel, weight] : row)
            sensitivity[static_cast<std::size_t>(pixel)] += weight;
    GaussianSmooth2D(&sensitivity, grid, smoothing_sigma_bins);
    const double peak = *std::max_element(sensitivity.begin(), sensitivity.end());
    const double floor_value = (peak > 0.0) ? floor_fraction * peak : 1.0;
    for (double& v : sensitivity) v = std::max(v, floor_value);
    return sensitivity;
}

MlemResult RunListModeMlem(const std::vector<SparseRow>& rows,
                           const std::vector<double>& sensitivity,
                           const ImageGrid2D& grid,
                           const MlemConfig& config) {
    MlemResult result;
    const std::size_t n_pixels = static_cast<std::size_t>(grid.NumPixels());
    result.image.assign(n_pixels, 1.0);
    if (rows.empty()) { result.stop_reason = "没有可用事例"; return result; }
    if (sensitivity.size() != n_pixels) { result.stop_reason = "灵敏度长度与网格不符"; return result; }

    // 掩掉灵敏度过低的像素：那里没有测量信息，乘性更新会把噪声放大成伪结构。
    const double sensitivity_peak = *std::max_element(sensitivity.begin(), sensitivity.end());
    const double sensitivity_threshold = config.minimum_sensitivity_fraction * sensitivity_peak;
    std::vector<char> in_reconstruction_region(n_pixels, 1);
    std::size_t n_masked = 0;
    for (std::size_t j = 0; j < n_pixels; ++j) {
        if (sensitivity[j] < sensitivity_threshold) {
            in_reconstruction_region[j] = 0;
            result.image[j] = 0.0;
            ++n_masked;
        }
    }
    result.n_pixels_masked = n_masked;

    std::vector<double> previous_image = result.image;
    double previous_log_likelihood = 0.0;
    int patience_counter = 0;

    for (int iteration = 1; iteration <= config.max_iterations; ++iteration) {
        // 前投影
        std::vector<double> projection(rows.size(), 0.0);
        double log_likelihood = 0.0;
        for (std::size_t i = 0; i < rows.size(); ++i) {
            double acc = 0.0;
            for (const auto& [pixel, weight] : rows[i])
                acc += weight * result.image[static_cast<std::size_t>(pixel)];
            projection[i] = std::max(acc, kEpsilon);
            log_likelihood += std::log(projection[i]);
        }
        // 反投影
        std::vector<double> backprojection(n_pixels, 0.0);
        for (std::size_t i = 0; i < rows.size(); ++i)
            for (const auto& [pixel, weight] : rows[i])
                backprojection[static_cast<std::size_t>(pixel)] += weight / projection[i];
        // 更新
        for (std::size_t j = 0; j < n_pixels; ++j) {
            if (!in_reconstruction_region[j]) { result.image[j] = 0.0; continue; }
            result.image[j] = std::max(result.image[j] * backprojection[j] / sensitivity[j], kEpsilon);
        }
        if (config.apply_inter_iteration_smoothing) {
            GaussianSmooth2D(&result.image, grid, config.smoothing_sigma_bins);
            for (std::size_t j = 0; j < n_pixels; ++j)
                if (!in_reconstruction_region[j]) result.image[j] = 0.0;
        }

        // 收敛量
        double numerator = 0.0, denominator = 0.0;
        for (std::size_t j = 0; j < n_pixels; ++j) {
            numerator += std::fabs(result.image[j] - previous_image[j]);
            denominator += std::fabs(previous_image[j]);
        }
        const double image_change = (denominator > 0.0) ? numerator / denominator : 0.0;
        const double ll_change = (iteration > 1 && std::fabs(previous_log_likelihood) > 0.0)
            ? std::fabs(log_likelihood - previous_log_likelihood) / std::fabs(previous_log_likelihood)
            : 1.0;

        result.history.push_back({iteration, log_likelihood, ll_change, image_change});
        result.iterations_run = iteration;

        const bool ll_converged = (iteration > 1) &&
            (ll_change < config.log_likelihood_relative_tolerance);
        const bool image_converged = image_change < config.image_relative_change_tolerance;
        if (ll_converged || image_converged) {
            ++patience_counter;
            if (patience_counter >= config.patience) {
                result.converged = true;
                result.stop_reason = ll_converged
                    ? "对数似然相对改善连续低于阈值"
                    : "图像相对变化连续低于阈值";
                break;
            }
        } else {
            patience_counter = 0;
        }
        previous_image = result.image;
        previous_log_likelihood = log_likelihood;
    }
    if (!result.converged && result.stop_reason.empty())
        result.stop_reason = "达到最大迭代次数仍未满足收敛判据";
    return result;
}

}  // namespace backscatter
