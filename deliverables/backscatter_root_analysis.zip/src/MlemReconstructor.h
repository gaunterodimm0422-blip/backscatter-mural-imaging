// ===========================================================================
//  MlemReconstructor.h —— 需求文档第五节：MLEM，参数化迭代次数 + 收敛判断。
//
//  关于"MLEM 的输入应该是什么"
//  ---------------------------
//  需求文档写"基于计算得到的空间点使用 MLEM"。严格的 MLEM 需要的是**系统矩阵**：
//  某个体素发出的事例被探测到的概率。只拿重建出的点云去迭代，本质上是对点云做
//  反卷积，不是极大似然。
//
//  本实现取两者之间、且物理上站得住的做法：
//    · 每个事例的**入射射线是精确已知的**（由符合标记给出，几何精度高）；
//    · 沿这条射线的**位置**由能量反解，带有可计算的不确定度
//      （sigma_t 由能量分辨经 dE/dtheta 传播而来，见 ComputePathSigmaMm）；
//    · 于是每个事例在网格上的行 = 射线经过的像素，权重为沿射线的高斯。
//  这就是 list-mode MLEM 的一行，用的是真实已知的信息，没有多假设。
//
//  灵敏度（每个像素被探测到的概率）由**参照跑**估计：把参照场的事例按同样方式
//  投到网格上再平滑。这样孔径衰减、探测器不均匀性都被吸收进灵敏度里。
//
//  纯 C++，不依赖 ROOT。
// ===========================================================================
#ifndef MLEM_RECONSTRUCTOR_H
#define MLEM_RECONSTRUCTOR_H

#include "BackscatterAnalysisConfig.h"
#include "EventBuilder.h"

#include <string>
#include <vector>

namespace backscatter {

struct ImageGrid2D {
    double x_min_mm = -60.0, x_max_mm = 60.0;
    int    x_bins = 60;
    double depth_min_mm = 0.0, depth_max_mm = 120.0;
    int    depth_bins = 60;

    int    NumPixels() const { return x_bins * depth_bins; }
    double XBinWidthMm() const { return (x_max_mm - x_min_mm) / x_bins; }
    double DepthBinWidthMm() const { return (depth_max_mm - depth_min_mm) / depth_bins; }
    double XCenterMm(int ix) const { return x_min_mm + (ix + 0.5) * XBinWidthMm(); }
    double DepthCenterMm(int iz) const { return depth_min_mm + (iz + 0.5) * DepthBinWidthMm(); }
    int    PixelIndex(int ix, int iz) const { return iz * x_bins + ix; }
    bool   Locate(double x_mm, double depth_mm, int* ix, int* iz) const;
};

ImageGrid2D MakeGrid(const MlemConfig& config);

// 稀疏行：(像素下标, 权重)
using SparseRow = std::vector<std::pair<int, double>>;

// 由能量分辨传播出的"沿射线位置"的标准差。
//   sigma_theta = sigma_E / |dE'/dtheta|，  sigma_t ~ |X - S| * sigma_theta / sin(theta)
double ComputePathSigmaMm(const ScatterVertexResult& vertex,
                          double backscatter_energy_keV,
                          double source_to_backscatter_distance_mm,
                          double energy_fwhm_fraction_at_511);

// 把一个通过判选的符合事例投影成系统矩阵的一行。
SparseRow BuildSystemMatrixRow(const CoincidencePair& pair,
                               const ImageGrid2D& grid,
                               double path_sigma_mm,
                               double n_sigma_range = 3.0);

// 由参照跑的事例估计每个像素的灵敏度（未归一化），再做一次高斯平滑并加下限。
std::vector<double> BuildSensitivityFromReference(const std::vector<SparseRow>& reference_rows,
                                                  const ImageGrid2D& grid,
                                                  double smoothing_sigma_bins,
                                                  double floor_fraction = 1.0e-3);

struct MlemIterationRecord {
    int    iteration = 0;
    double log_likelihood = 0.0;
    double log_likelihood_relative_change = 0.0;
    double image_relative_change = 0.0;
};

struct MlemResult {
    std::vector<double> image;
    std::vector<MlemIterationRecord> history;
    int  iterations_run = 0;
    std::size_t n_pixels_masked = 0;   // 因灵敏度过低而被排除的像素数
    bool converged = false;
    std::string stop_reason;
};

// list-mode MLEM。收敛判据见 MlemConfig。
MlemResult RunListModeMlem(const std::vector<SparseRow>& rows,
                           const std::vector<double>& sensitivity,
                           const ImageGrid2D& grid,
                           const MlemConfig& config);

}  // namespace backscatter
#endif  // MLEM_RECONSTRUCTOR_H
