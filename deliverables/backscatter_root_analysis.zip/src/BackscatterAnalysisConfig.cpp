#include "BackscatterAnalysisConfig.h"

namespace backscatter {

BranchNames MakeBranchNames(InputSchema schema) {
    BranchNames names;
    if (schema == InputSchema::kAdvisorSchema) {
        // 需求文档附1 的命名
        names.event_id       = "m_eventID";
        names.track_id       = "m_trackID";
        names.time           = "m_time";
        names.energy_deposit = "m_edep";
        names.position_x     = "m_posx";
        names.position_y     = "m_posy";
        names.position_z     = "m_posz";
        names.source_x       = "m_sourcePosX";
        names.source_y       = "m_sourcePosY";
        names.source_z       = "m_sourcePosZ";
        names.volume_id      = "m_volumeID";
        // 附1 的分支列表里没有能区分初级光子的字段。若数据里其实有，
        // 把下面两个名字改成实际的分支名即可，程序会自动启用该条判选。
        names.photon_id      = "m_photonID";
        names.primary_id     = "m_primaryID";
    }
    return names;   // 默认即 GATE 的命名
}

}  // namespace backscatter
