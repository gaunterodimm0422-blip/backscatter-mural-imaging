// ===========================================================================
//  HitReader.h —— 需求文档二-1：用 TTree 逐个读取 hit。
//  这是**唯一依赖 ROOT 的模块**，其余全部是纯 C++，可单独编译测试。
// ===========================================================================
#ifndef HIT_READER_H
#define HIT_READER_H

#include "BackscatterAnalysisConfig.h"
#include "EventBuilder.h"

#include <string>
#include <vector>

namespace backscatter {

struct HitReadResult {
    std::vector<Hit> tagging_hits;
    std::vector<Hit> backscatter_hits;
    long long n_entries_read = 0;
    bool has_photon_identity = false;
    bool ok = false;
    std::string message;
};

// 从一个 ROOT 文件里读出两个探测器的全部 hit。
//   kGateSchema     读 input.tagging_tree_name 与 input.backscatter_tree_name 两棵树
//   kAdvisorSchema  读 input.single_tree_name 一棵树，按 volumeID 分流
HitReadResult ReadHitsFromRootFile(const std::string& file_path, const InputConfig& input);

// 打印文件里有哪些树、每棵树有哪些分支。换新数据时先跑这个确认命名。
void PrintRootFileStructure(const std::string& file_path);

}  // namespace backscatter
#endif  // HIT_READER_H
