#include "ComptonKinematics.h"

#include <algorithm>
#include <cmath>

namespace backscatter {
namespace {
constexpr double kTiny = 1.0e-12;
}  // namespace

Vector3 operator+(const Vector3& a, const Vector3& b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
Vector3 operator-(const Vector3& a, const Vector3& b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
Vector3 operator*(const Vector3& a, double s) { return {a.x * s, a.y * s, a.z * s}; }
double  Dot(const Vector3& a, const Vector3& b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
double  Norm(const Vector3& a) { return std::sqrt(Dot(a, a)); }

Vector3 Normalize(const Vector3& a) {
    const double n = Norm(a);
    if (n < kTiny) return {0.0, 0.0, 0.0};
    return {a.x / n, a.y / n, a.z / n};
}

// ---------------------------------------------------------------- 三-1 ----
Line3D MakeLineThroughTwoPoints(const Vector3& from, const Vector3& to) {
    Line3D line;
    const Vector3 delta = to - from;
    const double length = Norm(delta);
    if (length < kTiny) return line;              // is_valid 保持 false
    line.origin = from;
    line.direction = delta * (1.0 / length);
    line.length_mm = length;
    line.is_valid = true;
    return line;
}

Line3D MakeIncidentRayFromTagging(const Vector3& source_position,
                                  const Vector3& tagging_hit_position) {
    // 两个湮没光子背靠背：进入物体的方向 = 由标记命中点指向源的方向。
    return MakeLineThroughTwoPoints(source_position,
                                    source_position + (source_position - tagging_hit_position));
}

// ---------------------------------------------------------------- 三-2 ----
ScatterAngleResult ScatterAngleFromScatteredEnergy(double scattered_energy_keV,
                                                   double incident_energy_keV) {
    ScatterAngleResult result;
    if (!(scattered_energy_keV > 0.0) || !(incident_energy_keV > 0.0)) return result;
    // cos(theta) = 1 - m_e c^2 * (1/E' - 1/E0)，在 E0 = m_e c^2 时化为 2 - E0/E'
    const double cos_theta =
        1.0 - kElectronRestEnergyKeV * (1.0 / scattered_energy_keV - 1.0 / incident_energy_keV);
    if (!(cos_theta >= -1.0 && cos_theta <= 1.0)) return result;   // 能量不在物理区间
    result.cos_theta = cos_theta;
    result.theta_rad = std::acos(cos_theta);
    result.is_valid = true;
    return result;
}

double ScatteredEnergyFromScatterAngle(double theta_rad, double incident_energy_keV) {
    const double denominator =
        1.0 + (incident_energy_keV / kElectronRestEnergyKeV) * (1.0 - std::cos(theta_rad));
    return incident_energy_keV / denominator;
}

// ---------------------------------------------------------------- 三-3 ----
Cone3D MakeScatterCone(const Vector3& backscatter_hit_position,
                       const Vector3& incident_direction,
                       double theta_rad) {
    Cone3D cone;
    const Vector3 axis = Normalize(incident_direction) * (-1.0);
    if (Norm(axis) < 0.5) return cone;                 // 入射方向退化
    if (!(theta_rad > 0.0 && theta_rad < M_PI)) return cone;
    cone.apex = backscatter_hit_position;
    cone.axis_direction = axis;
    cone.half_angle_rad = theta_rad;
    cone.is_valid = true;
    return cone;
}

// ------------------------------------------------------------ 内部工具 ----
namespace {

bool IsInsideObject(const Vector3& p, const GeometryConfig& g) {
    return (p.z <= g.object_surface_z_mm + 1.0e-9) && (p.z >= g.object_back_z_mm - 1.0e-9);
}

// 两种解法共用的收尾：判断顶点是否在物体内并填好结果。
void FinishVertex(ScatterVertexResult& r, const Line3D& ray,
                  const GeometryConfig& geometry, bool require_inside) {
    if (!(r.path_length_mm > geometry.vertex_path_length_min_mm &&
          r.path_length_mm < geometry.vertex_path_length_max_mm)) {
        r.is_valid = false;
        r.failure = VertexFailureCode::kPathLengthOutOfRange;
        return;
    }
    r.position = ray.origin + ray.direction * r.path_length_mm;
    if (require_inside && !IsInsideObject(r.position, geometry)) {
        r.is_valid = false;
        r.failure = VertexFailureCode::kVertexOutsideObject;
        return;
    }
    r.is_valid = true;
    r.failure = VertexFailureCode::kOk;
}

}  // namespace

// ------------------------------------------------------- 三-4 与 四-1 ----
ScatterVertexResult IntersectLineWithCone(const Line3D& incident_ray,
                                          const Cone3D& scatter_cone,
                                          const GeometryConfig& geometry,
                                          bool require_vertex_inside_object) {
    ScatterVertexResult result;
    if (!incident_ray.is_valid) { result.failure = VertexFailureCode::kInvalidLine; return result; }
    if (!scatter_cone.is_valid) { result.failure = VertexFailureCode::kUnphysicalEnergy; return result; }

    const double theta = scatter_cone.half_angle_rad;
    const double c = std::cos(theta);
    const double s = std::sin(theta);
    if (std::fabs(s) < 1.0e-9) { result.failure = VertexFailureCode::kDegenerateGeometry; return result; }

    const Vector3& S = incident_ray.origin;
    const Vector3& v = incident_ray.direction;
    const Vector3  d = scatter_cone.apex - S;
    const double   a = Dot(v, d);
    const double   d2 = Dot(d, d);

    // t^2 - 2 a t + (a^2 - c^2 d^2) / (1 - c^2) = 0
    const double one_minus_c2 = 1.0 - c * c;          // = sin^2(theta) > 0
    const double q = (a * a - c * c * d2) / one_minus_c2;
    const double discriminant = a * a - q;
    if (discriminant < 0.0) { result.failure = VertexFailureCode::kNoRealRoot; return result; }

    const double root_delta = std::sqrt(discriminant);
    const double t_plus  = a + root_delta;
    const double t_minus = a - root_delta;

    // 挑物理根：平方前的等式要求 sign(a - t) == sign(cos theta)，且 t > 0。
    double chosen = 0.0, other = 0.0;
    int n_pass = 0;
    for (double t : {t_minus, t_plus}) {
        if (!(t > 0.0)) continue;
        const double lhs = a - t;
        const bool sign_ok = (c >= 0.0) ? (lhs >= -1.0e-9) : (lhs <= 1.0e-9);
        if (!sign_ok) continue;
        ++n_pass;
        if (n_pass == 1) chosen = t; else other = t;
    }
    result.n_roots_passing = n_pass;
    result.root_other_mm = other;
    result.theta_rad = theta;
    const double dist_d = std::sqrt(d2);
    result.alpha_rad = (dist_d > kTiny)
        ? std::acos(std::max(-1.0, std::min(1.0, a / dist_d))) : 0.0;

    if (n_pass == 0) {
        result.failure = (t_plus <= 0.0 && t_minus <= 0.0)
            ? VertexFailureCode::kVertexBehindSource
            : VertexFailureCode::kNoRootPassesSignTest;
        return result;
    }
    if (n_pass == 2) {
        // 两个根都通过符号判定：取靠近源的那一个（散射顶点必在源与探测器之间）。
        if (other < chosen) std::swap(chosen, other);
        result.root_other_mm = other;
    }
    result.path_length_mm = chosen;
    FinishVertex(result, incident_ray, geometry, require_vertex_inside_object);
    return result;
}

ScatterVertexResult SolveScatterVertexClosedForm(const Vector3& source_position,
                                                 const Vector3& tagging_hit_position,
                                                 const Vector3& backscatter_hit_position,
                                                 double backscatter_energy_keV,
                                                 const GeometryConfig& geometry,
                                                 bool require_vertex_inside_object) {
    ScatterVertexResult result;
    const Line3D ray = MakeIncidentRayFromTagging(source_position, tagging_hit_position);
    if (!ray.is_valid) { result.failure = VertexFailureCode::kInvalidLine; return result; }

    const ScatterAngleResult angle = ScatterAngleFromScatteredEnergy(backscatter_energy_keV);
    if (!angle.is_valid) { result.failure = VertexFailureCode::kUnphysicalEnergy; return result; }

    const double theta = angle.theta_rad;
    const double sin_theta = std::sin(theta);
    if (std::fabs(sin_theta) < 1.0e-9) { result.failure = VertexFailureCode::kDegenerateGeometry; return result; }

    const Vector3 d = backscatter_hit_position - source_position;
    const double dist_d = Norm(d);
    if (dist_d < kTiny) { result.failure = VertexFailureCode::kDegenerateGeometry; return result; }

    const double cos_alpha = std::max(-1.0, std::min(1.0, Dot(ray.direction, d) / dist_d));
    const double alpha = std::acos(cos_alpha);

    // 三角形 源-顶点-命中点：顶角为 theta，源处夹角为 alpha，正弦定理给出
    const double t = dist_d * std::sin(theta - alpha) / sin_theta;

    result.theta_rad = theta;
    result.alpha_rad = alpha;
    result.n_roots_passing = 1;
    if (!(t > 0.0)) { result.failure = VertexFailureCode::kVertexBehindSource; return result; }
    result.path_length_mm = t;
    FinishVertex(result, ray, geometry, require_vertex_inside_object);
    return result;
}

const char* VertexFailureCodeName(VertexFailureCode code) {
    switch (code) {
        case VertexFailureCode::kOk:                  return "ok";
        case VertexFailureCode::kInvalidLine:         return "invalid_line";
        case VertexFailureCode::kUnphysicalEnergy:    return "unphysical_energy";
        case VertexFailureCode::kDegenerateGeometry:  return "degenerate_geometry";
        case VertexFailureCode::kNoRealRoot:          return "no_real_root";
        case VertexFailureCode::kNoRootPassesSignTest:return "no_root_passes_sign_test";
        case VertexFailureCode::kVertexBehindSource:  return "vertex_behind_source";
        case VertexFailureCode::kVertexOutsideObject: return "vertex_outside_object";
        case VertexFailureCode::kPathLengthOutOfRange: return "path_length_out_of_range";
    }
    return "unknown";
}

}  // namespace backscatter
