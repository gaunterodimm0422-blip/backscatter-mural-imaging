// ===========================================================================
//  EventBuilder.h —— 需求文档二-2、二-4、二-5 与四-2。
//    · 按 eventID 与探测器把 hit 聚合成"一个探测器上的一次作用"
//    · 施加探测器响应
//    · 判选，并把每一条切掉多少事例记成一张可审计的表
//  纯 C++，不依赖 ROOT。
// ===========================================================================
#ifndef EVENT_BUILDER_H
#define EVENT_BUILDER_H

#include "BackscatterAnalysisConfig.h"
#include "ComptonKinematics.h"
#include "DetectorResponse.h"

#include <map>
#include <string>
#include <utility>
#include <vector>

namespace backscatter {

// 一条原始 hit
struct Hit {
    long long event_id = -1;
    int    track_id = -1;
    double time_ns = 0.0;
    double energy_deposit_keV = 0.0;
    Vector3 position;
    Vector3 source_position;
    int    volume_id = -1;
    int    photon_id = -1;       // < 0 表示输入数据没有这个分支
    int    primary_id = -1;
    bool   has_photon_identity = false;
};

// 一个探测器上的一次作用（由同一 eventID 的若干 hit 合并而成）
struct DetectorEvent {
    long long event_id = -1;
    double total_energy_keV = 0.0;
    double time_ns = 0.0;
    Vector3 position;
    Vector3 source_position;
    int    n_hits = 0;
    int    photon_id = -1;
    int    primary_id = -1;
    bool   has_photon_identity = false;
    bool   is_valid = false;
};

// 需求文档二-2：按 eventID 聚合。位置按 mode，时间按 time_mode，能量求和。
std::map<long long, DetectorEvent> BuildDetectorEvents(
    const std::vector<Hit>& hits,
    HitCombinationMode position_mode,
    EventTimeMode time_mode);

// 一次符合：标记探测器与背散射探测器上的一对作用
struct CoincidencePair {
    DetectorEvent tagging;
    DetectorEvent backscatter;
    ScatterVertexResult vertex;
    bool passed_selection = false;
};

// 判选链条：有序记录每一条之后还剩多少事例
class SelectionCutFlow {
  public:
    void Begin(std::size_t n_initial);
    // 施加一条判选；返回该条之后的剩余数
    std::size_t Apply(const std::string& cut_name, std::size_t n_remaining);
    void Print(const char* title) const;
    const std::vector<std::pair<std::string, std::size_t>>& entries() const { return entries_; }

  private:
    std::vector<std::pair<std::string, std::size_t>> entries_;
};

// 把两个探测器的事件按 eventID 配对，施加响应与判选，并解出散射顶点。
// 返回所有配对（含未通过判选的，便于诊断）；cut_flow 记录每条判选的剩余数。
std::vector<CoincidencePair> BuildAndSelectCoincidences(
    const std::map<long long, DetectorEvent>& tagging_events,
    const std::map<long long, DetectorEvent>& backscatter_events,
    const AnalysisConfig& config,
    DetectorResponseApplier* response,
    SelectionCutFlow* cut_flow,
    bool* photon_identity_warning_emitted);

}  // namespace backscatter
#endif  // EVENT_BUILDER_H
