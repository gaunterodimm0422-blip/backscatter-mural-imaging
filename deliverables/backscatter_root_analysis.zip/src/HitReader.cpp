#include "HitReader.h"

#include <cstdio>
#include <memory>

#include "TBranch.h"
#include "TFile.h"
#include "TKey.h"
#include "TLeaf.h"
#include "TObjArray.h"
#include "TTree.h"

namespace backscatter {
namespace {

// 一棵树上要读的全部分支的地址。可选分支不存在时对应指针为 nullptr。
struct BranchBinding {
    Int_t    event_id = 0;
    Int_t    track_id = 0;
    Double_t time = 0.0;
    Float_t  energy_deposit = 0.0f;
    Float_t  position_x = 0.0f, position_y = 0.0f, position_z = 0.0f;
    Float_t  source_x = 0.0f, source_y = 0.0f, source_z = 0.0f;
    Int_t    volume_id = -1;
    Int_t    photon_id = -1, primary_id = -1;
    bool     has_volume_id = false;
    bool     has_photon_identity = false;
    bool     has_source = false;
};

bool HasBranch(TTree* tree, const std::string& name) {
    return tree != nullptr && tree->GetBranch(name.c_str()) != nullptr;
}

bool BindBranches(TTree* tree, const BranchNames& names, BranchBinding* b, std::string* message) {
    const char* required[] = {names.event_id.c_str(), names.time.c_str(),
                              names.energy_deposit.c_str(), names.position_x.c_str(),
                              names.position_y.c_str(), names.position_z.c_str()};
    for (const char* name : required) {
        if (!HasBranch(tree, name)) {
            *message = std::string("缺少必需分支：") + name;
            return false;
        }
    }
    tree->SetBranchAddress(names.event_id.c_str(), &b->event_id);
    tree->SetBranchAddress(names.time.c_str(), &b->time);
    tree->SetBranchAddress(names.energy_deposit.c_str(), &b->energy_deposit);
    tree->SetBranchAddress(names.position_x.c_str(), &b->position_x);
    tree->SetBranchAddress(names.position_y.c_str(), &b->position_y);
    tree->SetBranchAddress(names.position_z.c_str(), &b->position_z);

    if (HasBranch(tree, names.track_id)) tree->SetBranchAddress(names.track_id.c_str(), &b->track_id);
    if (HasBranch(tree, names.volume_id)) {
        tree->SetBranchAddress(names.volume_id.c_str(), &b->volume_id);
        b->has_volume_id = true;
    }
    b->has_source = HasBranch(tree, names.source_x) && HasBranch(tree, names.source_y) &&
                    HasBranch(tree, names.source_z);
    if (b->has_source) {
        tree->SetBranchAddress(names.source_x.c_str(), &b->source_x);
        tree->SetBranchAddress(names.source_y.c_str(), &b->source_y);
        tree->SetBranchAddress(names.source_z.c_str(), &b->source_z);
    }
    b->has_photon_identity = HasBranch(tree, names.photon_id) && HasBranch(tree, names.primary_id);
    if (b->has_photon_identity) {
        tree->SetBranchAddress(names.photon_id.c_str(), &b->photon_id);
        tree->SetBranchAddress(names.primary_id.c_str(), &b->primary_id);
    }
    return true;
}

Hit MakeHit(const BranchBinding& b, const BranchNames& names, const GeometryConfig* fallback_geometry) {
    Hit hit;
    hit.event_id = b.event_id;
    hit.track_id = b.track_id;
    hit.time_ns = b.time * names.time_to_ns;
    hit.energy_deposit_keV = b.energy_deposit * names.energy_deposit_to_keV;
    hit.position = {b.position_x, b.position_y, b.position_z};
    if (b.has_source) {
        hit.source_position = {b.source_x, b.source_y, b.source_z};
    } else if (fallback_geometry != nullptr) {
        hit.source_position = {fallback_geometry->source_x_mm, fallback_geometry->source_y_mm,
                               fallback_geometry->source_z_mm};
    }
    hit.volume_id = b.volume_id;
    hit.photon_id = b.photon_id;
    hit.primary_id = b.primary_id;
    hit.has_photon_identity = b.has_photon_identity;
    return hit;
}

}  // namespace

HitReadResult ReadHitsFromRootFile(const std::string& file_path, const InputConfig& input) {
    HitReadResult result;
    std::unique_ptr<TFile> file(TFile::Open(file_path.c_str(), "READ"));
    if (file == nullptr || file->IsZombie()) {
        result.message = "打不开文件：" + file_path;
        return result;
    }

    auto read_tree = [&](const std::string& tree_name, std::vector<Hit>* out_a,
                         std::vector<Hit>* out_b) -> bool {
        TTree* tree = dynamic_cast<TTree*>(file->Get(tree_name.c_str()));
        if (tree == nullptr) { result.message = "找不到树：" + tree_name; return false; }
        BranchBinding binding;
        std::string message;
        if (!BindBranches(tree, input.branches, &binding, &message)) {
            result.message = tree_name + "：" + message;
            return false;
        }
        if (binding.has_photon_identity) result.has_photon_identity = true;
        const Long64_t n = tree->GetEntries();
        for (Long64_t i = 0; i < n; ++i) {
            tree->GetEntry(i);
            ++result.n_entries_read;
            const Hit hit = MakeHit(binding, input.branches, nullptr);
            if (out_b == nullptr) { out_a->push_back(hit); continue; }
            // 单树模式：按 volumeID 分流
            if (binding.has_volume_id && binding.volume_id == input.tagging_volume_id)
                out_a->push_back(hit);
            else if (binding.has_volume_id && binding.volume_id == input.backscatter_volume_id)
                out_b->push_back(hit);
        }
        tree->ResetBranchAddresses();
        return true;
    };

    if (input.schema == InputSchema::kGateSchema) {
        if (!read_tree(input.tagging_tree_name, &result.tagging_hits, nullptr)) return result;
        if (!read_tree(input.backscatter_tree_name, &result.backscatter_hits, nullptr)) return result;
    } else {
        if (!read_tree(input.single_tree_name, &result.tagging_hits, &result.backscatter_hits))
            return result;
    }
    result.ok = true;
    return result;
}

void PrintRootFileStructure(const std::string& file_path) {
    std::unique_ptr<TFile> file(TFile::Open(file_path.c_str(), "READ"));
    if (file == nullptr || file->IsZombie()) {
        std::printf("打不开文件：%s\n", file_path.c_str());
        return;
    }
    std::printf("文件 %s 的结构\n", file_path.c_str());
    TIter next(file->GetListOfKeys());
    while (TKey* key = dynamic_cast<TKey*>(next())) {
        TTree* tree = dynamic_cast<TTree*>(key->ReadObj());
        if (tree == nullptr) continue;
        std::printf("  树 %-24s 条目数 %lld\n", tree->GetName(), tree->GetEntries());
        TObjArray* branches = tree->GetListOfBranches();
        for (int i = 0; i < branches->GetEntries(); ++i) {
            TBranch* branch = dynamic_cast<TBranch*>(branches->At(i));
            if (branch == nullptr) continue;
            TLeaf* leaf = branch->GetLeaf(branch->GetName());
            std::printf("      %-22s %s\n", branch->GetName(),
                        (leaf != nullptr) ? leaf->GetTypeName() : "?");
        }
    }
}

}  // namespace backscatter
