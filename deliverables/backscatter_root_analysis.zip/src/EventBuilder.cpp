#include "EventBuilder.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

namespace backscatter {
namespace {

constexpr double kDegToRad = M_PI / 180.0;

double PolarAngleDegFromZ(const Vector3& v) {
    const double n = Norm(v);
    if (n < 1.0e-12) return 0.0;
    return std::acos(std::max(-1.0, std::min(1.0, v.z / n))) / kDegToRad;
}

}  // namespace

std::map<long long, DetectorEvent> BuildDetectorEvents(const std::vector<Hit>& hits,
                                                       HitCombinationMode position_mode,
                                                       EventTimeMode time_mode) {
    struct Accumulator {
        double energy_sum = 0.0;
        Vector3 weighted_position;          // 能量加权位置和
        double  max_energy = -1.0;
        Vector3 max_energy_position;
        double  max_energy_time = 0.0;
        double  earliest_time = 0.0;
        Vector3 earliest_position;
        bool    has_any = false;
        int     n_hits = 0;
        Vector3 source_position;
        int     photon_id = -1, primary_id = -1;
        bool    has_photon_identity = false;
    };

    std::map<long long, Accumulator> accumulators;
    for (const Hit& hit : hits) {
        if (!(hit.energy_deposit_keV > 0.0)) continue;
        Accumulator& acc = accumulators[hit.event_id];
        acc.energy_sum += hit.energy_deposit_keV;
        acc.weighted_position = acc.weighted_position + hit.position * hit.energy_deposit_keV;
        ++acc.n_hits;
        acc.source_position = hit.source_position;
        if (hit.has_photon_identity) {
            acc.has_photon_identity = true;
            acc.photon_id = hit.photon_id;
            acc.primary_id = hit.primary_id;
        }
        if (hit.energy_deposit_keV > acc.max_energy) {
            acc.max_energy = hit.energy_deposit_keV;
            acc.max_energy_position = hit.position;
            acc.max_energy_time = hit.time_ns;
        }
        if (!acc.has_any || hit.time_ns < acc.earliest_time) {
            acc.earliest_time = hit.time_ns;
            acc.earliest_position = hit.position;
        }
        acc.has_any = true;
    }

    std::map<long long, DetectorEvent> events;
    for (const auto& [event_id, acc] : accumulators) {
        if (!acc.has_any || !(acc.energy_sum > 0.0)) continue;
        DetectorEvent e;
        e.event_id = event_id;
        e.total_energy_keV = acc.energy_sum;               // 需求文档：能量为各 hit 之和
        e.n_hits = acc.n_hits;
        e.source_position = acc.source_position;
        e.photon_id = acc.photon_id;
        e.primary_id = acc.primary_id;
        e.has_photon_identity = acc.has_photon_identity;
        switch (position_mode) {
            case HitCombinationMode::kEnergyWeightedCentroid:
                e.position = acc.weighted_position * (1.0 / acc.energy_sum);
                break;
            case HitCombinationMode::kMaxEnergyDeposit:
                e.position = acc.max_energy_position;
                break;
            case HitCombinationMode::kEarliestHit:
                e.position = acc.earliest_position;
                break;
        }
        e.time_ns = (time_mode == EventTimeMode::kTimeOfMaxEnergyDeposit)
                        ? acc.max_energy_time : acc.earliest_time;
        e.is_valid = true;
        events.emplace(event_id, e);
    }
    return events;
}

void SelectionCutFlow::Begin(std::size_t n_initial) {
    entries_.clear();
    entries_.emplace_back("输入配对数", n_initial);
}

std::size_t SelectionCutFlow::Apply(const std::string& cut_name, std::size_t n_remaining) {
    entries_.emplace_back(cut_name, n_remaining);
    return n_remaining;
}

void SelectionCutFlow::Print(const char* title) const {
    std::printf("\n%s\n", title);
    std::printf("  %-34s %12s %10s\n", "判选条件", "剩余事例", "切掉比例");
    std::size_t previous = entries_.empty() ? 0 : entries_.front().second;
    for (const auto& [name, count] : entries_) {
        const double removed_fraction =
            (previous > 0) ? 100.0 * static_cast<double>(previous - count) / static_cast<double>(previous) : 0.0;
        std::printf("  %-34s %12zu %9.2f%%\n", name.c_str(), count, removed_fraction);
        previous = count;
    }
}

std::vector<CoincidencePair> BuildAndSelectCoincidences(
    const std::map<long long, DetectorEvent>& tagging_events,
    const std::map<long long, DetectorEvent>& backscatter_events,
    const AnalysisConfig& config,
    DetectorResponseApplier* response,
    SelectionCutFlow* cut_flow,
    bool* photon_identity_warning_emitted) {

    const SelectionConfig& sel = config.selection;
    const GeometryConfig&  geo = config.geometry;

    // ---- 先按 eventID 配对 ----
    std::vector<CoincidencePair> pairs;
    for (const auto& [event_id, tag_event] : tagging_events) {
        const auto it = backscatter_events.find(event_id);
        if (it == backscatter_events.end()) continue;
        CoincidencePair pair;
        pair.tagging = tag_event;
        pair.backscatter = it->second;
        pairs.push_back(pair);
    }
    if (cut_flow != nullptr) cut_flow->Begin(pairs.size());

    // ---- 施加探测器响应（需求文档二-3），必须在开能量窗之前 ----
    const DetectorResolution tag_res = TaggingResolution(config.response);
    const DetectorResolution bs_res  = BackscatterResolution(config.response);
    for (CoincidencePair& p : pairs) {
        response->Apply(tag_res, &p.tagging.position, &p.tagging.total_energy_keV, &p.tagging.time_ns);
        response->Apply(bs_res, &p.backscatter.position, &p.backscatter.total_energy_keV,
                        &p.backscatter.time_ns);
    }

    // ---- 逐条判选。keep 标记逐步收紧，cut_flow 记录每条之后的剩余数。----
    std::vector<char> keep(pairs.size(), 1);
    auto count_kept = [&keep]() {
        return static_cast<std::size_t>(std::count(keep.begin(), keep.end(), 1));
    };
    auto apply_cut = [&](const std::string& name, auto&& predicate) {
        for (std::size_t i = 0; i < pairs.size(); ++i) {
            if (keep[i] && !predicate(pairs[i])) keep[i] = 0;
        }
        if (cut_flow != nullptr) cut_flow->Apply(name, count_kept());
    };

    apply_cut("两个探测器都有能量沉积", [](const CoincidencePair& p) {
        return p.tagging.total_energy_keV > 0.0 && p.backscatter.total_energy_keV > 0.0;
    });

    if (sel.require_different_primary_photons) {
        bool identity_available = false;
        for (const CoincidencePair& p : pairs) {
            if (p.tagging.has_photon_identity && p.backscatter.has_photon_identity) {
                identity_available = true; break;
            }
        }
        if (!identity_available) {
            if (photon_identity_warning_emitted != nullptr && !*photon_identity_warning_emitted) {
                std::printf(
                    "\n  [警告] 输入数据没有 photonID / primaryID 一类分支，无法执行\n"
                    "         \"两个 hit 来自不同初级光子\" 这一条判选，本条已跳过。\n"
                    "         后果：同一个光子先打背散射探测器、散射后又打标记探测器的事例\n"
                    "         会被当成合法符合，其运动学完全错误。见 README 第 4 节。\n");
                *photon_identity_warning_emitted = true;
            }
            if (cut_flow != nullptr) cut_flow->Apply("不同初级光子（数据缺分支，跳过）", count_kept());
        } else {
            apply_cut("两个 hit 来自不同初级光子", [](const CoincidencePair& p) {
                if (!p.tagging.has_photon_identity || !p.backscatter.has_photon_identity) return true;
                return p.tagging.photon_id != p.backscatter.photon_id;
            });
        }
    }

    apply_cut("符合时间窗", [&](const CoincidencePair& p) {
        return std::fabs(p.tagging.time_ns - p.backscatter.time_ns) <= sel.coincidence_window_ns;
    });
    apply_cut("标记探测器能量窗", [&](const CoincidencePair& p) {
        return p.tagging.total_energy_keV >= sel.tagging_energy_window_low_keV &&
               p.tagging.total_energy_keV <= sel.tagging_energy_window_high_keV;
    });
    apply_cut("背散射探测器能量窗", [&](const CoincidencePair& p) {
        return p.backscatter.total_energy_keV >= sel.backscatter_energy_window_low_keV &&
               p.backscatter.total_energy_keV <= sel.backscatter_energy_window_high_keV;
    });

    if (sel.apply_backscatter_active_radius) {
        apply_cut("背散射探测器有效半径", [&](const CoincidencePair& p) {
            const double dx = p.backscatter.position.x - p.backscatter.source_position.x;
            const double dy = p.backscatter.position.y - p.backscatter.source_position.y;
            const double r = std::sqrt(dx * dx + dy * dy);
            return r >= geo.backscatter_inner_radius_mm && r <= geo.backscatter_outer_radius_mm;
        });
    }
    if (sel.apply_tagging_active_area) {
        apply_cut("标记探测器有效面积", [&](const CoincidencePair& p) {
            const double dx = std::fabs(p.tagging.position.x - p.tagging.source_position.x);
            const double dy = std::fabs(p.tagging.position.y - p.tagging.source_position.y);
            return dx <= geo.tagging_half_width_mm && dy <= geo.tagging_half_width_mm;
        });
    }
    if (sel.apply_incident_polar_angle) {
        apply_cut("入射极角上限", [&](const CoincidencePair& p) {
            const Vector3 tag_vector = p.tagging.position - p.tagging.source_position;
            return PolarAngleDegFromZ(tag_vector) <= sel.incident_polar_angle_max_deg;
        });
    }

    // ---- 解散射顶点（需求文档三、四）----
    for (std::size_t i = 0; i < pairs.size(); ++i) {
        if (!keep[i]) continue;
        CoincidencePair& p = pairs[i];
        p.vertex = SolveScatterVertexClosedForm(
            p.tagging.source_position, p.tagging.position, p.backscatter.position,
            p.backscatter.total_energy_keV, geo, sel.require_vertex_inside_object);
    }
    apply_cut("散射顶点可解（含路径区间与物体内判定）",
              [](const CoincidencePair& p) { return p.vertex.is_valid; });

    if (sel.apply_scatter_angle_range) {
        apply_cut("散射角范围", [&](const CoincidencePair& p) {
            const double theta_deg = p.vertex.theta_rad / kDegToRad;
            return theta_deg >= sel.scatter_angle_min_deg && theta_deg <= sel.scatter_angle_max_deg;
        });
    }

    for (std::size_t i = 0; i < pairs.size(); ++i) pairs[i].passed_selection = (keep[i] != 0);
    return pairs;
}

}  // namespace backscatter
