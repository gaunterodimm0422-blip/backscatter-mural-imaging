#include "DetectorResponse.h"

#include <cmath>

namespace backscatter {
namespace {
constexpr double kFwhmToSigma = 1.0 / 2.3548200450309493;   // 1 / (2 sqrt(2 ln2))
}

double EnergyResolutionFwhmKeV(double energy_keV, double fwhm_fraction_at_511) {
    if (!(energy_keV > 0.0)) return 0.0;
    return fwhm_fraction_at_511 * kAnnihilationPhotonEnergyKeV *
           std::sqrt(energy_keV / kAnnihilationPhotonEnergyKeV);
}

double EnergyResolutionSigmaKeV(double energy_keV, double fwhm_fraction_at_511) {
    return EnergyResolutionFwhmKeV(energy_keV, fwhm_fraction_at_511) * kFwhmToSigma;
}

double QuantizeToVoxelCenter(double value_mm, double voxel_size_mm, double origin_mm) {
    if (!(voxel_size_mm > 0.0)) return value_mm;
    return origin_mm + (std::floor((value_mm - origin_mm) / voxel_size_mm) + 0.5) * voxel_size_mm;
}

DetectorResolution TaggingResolution(const DetectorResponseConfig& c) {
    DetectorResolution r;
    r.position_x_mm = c.tagging_position_resolution_x_mm;
    r.position_y_mm = c.tagging_position_resolution_y_mm;
    r.position_z_mm = c.tagging_position_resolution_z_mm;
    r.energy_fwhm_fraction_at_511 = c.tagging_energy_fwhm_fraction_at_511;
    r.time_fwhm_ns = c.time_resolution_fwhm_ns;
    return r;
}

DetectorResolution BackscatterResolution(const DetectorResponseConfig& c) {
    DetectorResolution r;
    r.position_x_mm = c.backscatter_position_resolution_x_mm;
    r.position_y_mm = c.backscatter_position_resolution_y_mm;
    r.position_z_mm = c.backscatter_position_resolution_z_mm;
    r.energy_fwhm_fraction_at_511 = c.backscatter_energy_fwhm_fraction_at_511;
    r.time_fwhm_ns = c.time_resolution_fwhm_ns;
    return r;
}

DetectorResponseApplier::DetectorResponseApplier(const DetectorResponseConfig& config)
    : config_(config), generator_(config.random_seed) {}

void DetectorResponseApplier::Reset() { generator_.seed(config_.random_seed); }

void DetectorResponseApplier::Apply(const DetectorResolution& resolution,
                                    Vector3* position, double* energy_keV, double* time_ns) {
    if (energy_keV != nullptr && *energy_keV > 0.0) {
        const double sigma = EnergyResolutionSigmaKeV(*energy_keV,
                                                      resolution.energy_fwhm_fraction_at_511);
        *energy_keV += sigma * standard_normal_(generator_);
    }
    if (time_ns != nullptr) {
        const double sigma = resolution.time_fwhm_ns * kFwhmToSigma;
        *time_ns += sigma * standard_normal_(generator_);
    }
    if (position != nullptr) {
        if (config_.position_model == PositionResponseModel::kVoxelCenterQuantization) {
            position->x = QuantizeToVoxelCenter(position->x, resolution.position_x_mm);
            position->y = QuantizeToVoxelCenter(position->y, resolution.position_y_mm);
            position->z = QuantizeToVoxelCenter(position->z, resolution.position_z_mm);
        } else {
            position->x += resolution.position_x_mm * kFwhmToSigma * standard_normal_(generator_);
            position->y += resolution.position_y_mm * kFwhmToSigma * standard_normal_(generator_);
            position->z += resolution.position_z_mm * kFwhmToSigma * standard_normal_(generator_);
        }
    }
}

}  // namespace backscatter
