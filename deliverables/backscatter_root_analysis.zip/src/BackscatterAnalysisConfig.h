// ===========================================================================
//  BackscatterAnalysisConfig.h
//
//  双 511 keV 符合标记背散射成像 —— 全部可调参数集中在本文件。
//
//  探测器命名约定（重要）
//  ----------------------
//    TaggingDetector      标记探测器：接住 gamma1，由它定出 gamma2 的入射方向
//    BackscatterDetector  背散射探测器：接住被检测物体散射回来的 gamma2
//  在需求文档里它们分别叫 Detector1 与 Detector2。
//  在 GATE 工程里它们分别叫 crystal（Hits_crystal）与 BSdetector（Hits_BSdetector），
//  编号正好相反，所以本程序一律用上面两个名字，不用编号，避免串。
//
//  单位：长度 mm，能量 keV，时间 ns。
// ===========================================================================
#ifndef BACKSCATTER_ANALYSIS_CONFIG_H
#define BACKSCATTER_ANALYSIS_CONFIG_H

#include <string>
#include <cstdint>

namespace backscatter {

// ---------------------------------------------------------------------------
// 物理常数
// ---------------------------------------------------------------------------
constexpr double kAnnihilationPhotonEnergyKeV = 511.0;  // 湮没光子能量
constexpr double kElectronRestEnergyKeV       = 511.0;  // 电子静止能量 m_e c^2

// 由 E' = E0 / (2 - cos(theta)) 反解可知 cos(theta) 在 [-1, 1] 内时
// 散射后能量必然落在 [E0/3, E0] = [170.33, 511] keV。窗口设置不应越过此界。
constexpr double kMinPhysicalScatteredEnergyKeV = kAnnihilationPhotonEnergyKeV / 3.0;

// ---------------------------------------------------------------------------
// 一、几何：源与两个探测器的相对位置
// ---------------------------------------------------------------------------
struct GeometryConfig {
    // 源位置。若输入数据里带 sourcePos 分支，逐事例读取的值优先于此处的默认值。
    double source_x_mm = 0.0;
    double source_y_mm = 0.0;
    double source_z_mm = 17.5;

    // 标记探测器：正方形像素阵列，法线沿 +z
    double tagging_center_z_mm     = 60.0;  // 阵列中心的 z
    double tagging_half_width_mm   = 25.0;  // 有效面积半宽（x 与 y 同）
    double tagging_thickness_mm    = 20.0;

    // 背散射探测器：环形，法线沿 +z
    double backscatter_center_z_mm = 17.5;
    double backscatter_inner_radius_mm = 20.0;
    double backscatter_outer_radius_mm = 200.0;
    double backscatter_thickness_mm    = 15.0;

    // 被检测物体所占的 z 区间（物体表面 z = 0，物体在 z < 0 一侧）。
    // 用于判断解出的散射顶点是否落在物体内部。
    double object_surface_z_mm = 0.0;
    double object_back_z_mm    = -140.0;

    // 解出的散射顶点到源的距离必须落在这个区间内。
    // 下限剔除"顶点几乎贴在源上"的病态解，上限剔除穿出量程的解。
    // 这两条属于需求文档四-2（物理约束）里应当补齐的内容。
    double vertex_path_length_min_mm = 1.0;
    double vertex_path_length_max_mm = 280.0;
};

// ---------------------------------------------------------------------------
// 二、探测器响应：位置、能量、时间分辨率
//
//   位置：按需求文档取"读出体素尺寸"，即把坐标量化到体素中心。
//         若供货方给出的其实是高斯 FWHM，把 position_model 改成 kGaussianFwhm。
//   能量：FWHM/E 在 511 keV 处等于 energy_fwhm_fraction_at_511，
//         其他能量按 sqrt(E) 标度：FWHM(E) = frac * 511 * sqrt(E / 511)。
//   时间：高斯 FWHM。
// ---------------------------------------------------------------------------
enum class PositionResponseModel {
    kVoxelCenterQuantization,  // 量化到体素中心（默认）
    kGaussianFwhm              // 高斯展宽
};

struct DetectorResponseConfig {
    // ---- 标记探测器（需求文档中的 Detector1）----
    double tagging_position_resolution_x_mm = 1.0;
    double tagging_position_resolution_y_mm = 1.0;
    double tagging_position_resolution_z_mm = 2.5;
    double tagging_energy_fwhm_fraction_at_511 = 0.15;   // 需求文档给定 15%

    // ---- 背散射探测器（需求文档中的 Detector2）----
    double backscatter_position_resolution_x_mm = 1.5;
    double backscatter_position_resolution_y_mm = 1.5;
    double backscatter_position_resolution_z_mm = 5.0;
    double backscatter_energy_fwhm_fraction_at_511 = 0.08;

    // ---- 两个探测器共用 ----
    double time_resolution_fwhm_ns = 1.0;

    PositionResponseModel position_model = PositionResponseModel::kVoxelCenterQuantization;

    // 固定随机种子，保证同一份输入每次得到逐位相同的结果。
    std::uint64_t random_seed = 24080601ULL;
};

// ---------------------------------------------------------------------------
// 三、事件重建：一个事件内多个 hit 如何合并成一个"作用点"
//
//   kEnergyWeightedCentroid  能量加权重心（需求文档指定，默认）
//   kMaxEnergyDeposit        取能量沉积最大的那个 hit 的位置
//   kEarliestHit             取时间最早的那个 hit 的位置
//
//   关于这三种的实测差别，见 README 第 3 节。默认保持需求文档的选择，
//   改这一项即可自行复现对比，无需改动其他任何代码。
// ---------------------------------------------------------------------------
enum class HitCombinationMode {
    kEnergyWeightedCentroid,
    kMaxEnergyDeposit,
    kEarliestHit
};

// 时间取值方式：需求文档指定"用能量沉积最大 hit 的时间"。
enum class EventTimeMode {
    kTimeOfMaxEnergyDeposit,  // 需求文档指定，默认
    kEarliestTime
};

struct EventBuildingConfig {
    HitCombinationMode tagging_position_mode =
        HitCombinationMode::kEnergyWeightedCentroid;
    HitCombinationMode backscatter_position_mode =
        HitCombinationMode::kEnergyWeightedCentroid;
    EventTimeMode time_mode = EventTimeMode::kTimeOfMaxEnergyDeposit;
};

// ---------------------------------------------------------------------------
// 四、事件判选
// ---------------------------------------------------------------------------
struct SelectionConfig {
    // 能量窗（需求文档给定）
    double tagging_energy_window_low_keV      = 400.0;
    double tagging_energy_window_high_keV     = 600.0;
    double backscatter_energy_window_low_keV  = 175.0;
    double backscatter_energy_window_high_keV = 260.0;

    // 符合窗（需求文档给定）
    double coincidence_window_ns = 10.0;

    // 几何判选：两个探测器的有效区域
    bool   apply_tagging_active_area      = true;
    bool   apply_backscatter_active_radius = true;

    // 入射极角上限：源发射锥的半角，超出的事例不可能来自同一次背靠背湮没
    bool   apply_incident_polar_angle = true;
    double incident_polar_angle_max_deg = 45.0;

    // 散射角范围。背散射几何下应大于 90 度；上限 180 度。
    bool   apply_scatter_angle_range = true;
    double scatter_angle_min_deg = 90.0;
    double scatter_angle_max_deg = 180.0;

    // 要求两个 hit 来自不同的初级光子。
    // 输入数据若没有 photonID / primaryID 一类分支，这一条无法执行，
    // 程序会打印一次警告并跳过。详见 README 第 4 节——这是一条实质判选，
    // 不执行时，"同一个光子先打背散射探测器、散射后又打标记探测器"的事例
    // 会被当成合法符合，运动学完全错误。
    bool   require_different_primary_photons = true;

    // 解出的散射顶点必须落在被检测物体内部
    bool   require_vertex_inside_object = true;
};

// ---------------------------------------------------------------------------
// 五、MLEM 重建
// ---------------------------------------------------------------------------
struct MlemConfig {
    // 重建网格（对圆柱对称的体模，沿 y 积分后用 x-深度 二维网格）
    double grid_x_min_mm = -60.0;
    double grid_x_max_mm =  60.0;
    int    grid_x_bins   = 60;
    double grid_depth_min_mm = 0.0;
    double grid_depth_max_mm = 120.0;
    int    grid_depth_bins   = 60;

    int    max_iterations = 200;

    // 收敛判据：相邻两次迭代的对数似然相对改善小于 tolerance，
    // 并连续满足 patience 次，即认为收敛并停止。
    double log_likelihood_relative_tolerance = 1.0e-6;
    int    patience = 3;

    // 图像相对变化的上限判据（另一个独立的停止条件）
    double image_relative_change_tolerance = 1.0e-4;

    // 灵敏度低于峰值这个比例的像素，直接排除出重建区域（图像里保持为 0）。
    // 不做这一步，MLEM 的乘性更新会在灵敏度近于零的网格边缘除出巨大的值，
    // 图像峰值会跑到视野边缘上去——这是 MLEM 最常见的伪影，必须掩掉。
    double minimum_sensitivity_fraction = 0.05;

    // MLEM 会随迭代放大噪声。设为 true 时每次迭代后做一次高斯平滑，
    // 相当于 one-step-late 正则化。sigma 单位是"格"。
    bool   apply_inter_iteration_smoothing = false;
    double smoothing_sigma_bins = 0.8;
};

// ---------------------------------------------------------------------------
// 六、输入数据的分支命名
//
//   kAdvisorSchema  需求文档附1 的命名：单棵树，m_ 前缀，用 m_volumeID 区分探测器
//   kGateSchema     GATE 默认输出：每个探测器一棵树，无前缀
//
//   两种都支持。默认用 kGateSchema，因为目前手上唯一存在的数据是 GATE 产生的。
// ---------------------------------------------------------------------------
enum class InputSchema { kAdvisorSchema, kGateSchema };

struct BranchNames {
    std::string event_id   = "eventID";
    std::string track_id   = "trackID";
    std::string time       = "time";
    std::string energy_deposit = "edep";
    std::string position_x = "posX";
    std::string position_y = "posY";
    std::string position_z = "posZ";
    std::string source_x   = "sourcePosX";
    std::string source_y   = "sourcePosY";
    std::string source_z   = "sourcePosZ";
    std::string volume_id  = "volumeID";
    // 用于判断两个 hit 是否来自同一个初级光子。GATE 提供 photonID / primaryID。
    std::string photon_id  = "photonID";
    std::string primary_id = "primaryID";

    // 能量沉积的单位换算系数：GATE 以 MeV 记录，需乘 1000 变成 keV。
    double energy_deposit_to_keV = 1000.0;
    // 时间的单位换算系数：GATE 以 s 记录，需乘 1e9 变成 ns。
    double time_to_ns = 1.0e9;
};

BranchNames MakeBranchNames(InputSchema schema);

struct InputConfig {
    InputSchema schema = InputSchema::kGateSchema;

    // kGateSchema：两棵树的名字
    std::string tagging_tree_name     = "Hits_crystal";
    std::string backscatter_tree_name = "Hits_BSdetector";

    // kAdvisorSchema：一棵树的名字，外加区分两个探测器的 volumeID 取值
    std::string single_tree_name = "Hits";
    int tagging_volume_id     = 1;
    int backscatter_volume_id = 2;

    BranchNames branches = MakeBranchNames(InputSchema::kGateSchema);
};

// ---------------------------------------------------------------------------
// 总配置
// ---------------------------------------------------------------------------
struct AnalysisConfig {
    GeometryConfig         geometry;
    DetectorResponseConfig response;
    EventBuildingConfig    event_building;
    SelectionConfig        selection;
    MlemConfig             mlem;
    InputConfig            input;
};

}  // namespace backscatter
#endif  // BACKSCATTER_ANALYSIS_CONFIG_H
