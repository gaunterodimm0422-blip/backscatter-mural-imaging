#!/usr/bin/env bash
# M1：壁画地仗层空鼓的多位姿检出与深度定位。
#
# 为什么跑这个
# ------------
# 主目标是用这台设备分析壁画损伤。此前所有性能数字都是"真空里一根 φ2 mm 细杆"
# 测出来的——那是亮背景上的一个亮点，正对比、无背景。壁画空鼓是反过来的：
# 满是散射的泥层里少掉一层空气，负对比、强背景。这两件事从未验证过是否等价。
# 这一轮就是验它。
#
# 体模（phantom_mural.mac）
# -------------------------
#   细泥层  5 mm    地仗材料 1.70 g/cm3     莫高窟、榆林窟实测约 0.5 cm
#   粗泥层 35 mm    同材料                  莫高窟等平均 3.5 cm ± 0.5 cm
#   支撑体 100 mm   砂砾岩 2.20 g/cm3       玉门组崖体
#   空鼓    5 mm 厚，深 35 mm，贴在地仗/支撑体界面，横向 120 x 120 mm
#
# 空鼓参数为什么这么取
#   深度 35 mm  —— 文献：壁画空鼓深度一般 2~5 cm，很少超过 10 cm；
#                  35 mm 同时正好落在地仗与支撑体的界面，是最常见的一类。
#   厚度  5 mm  —— 文献里 GPR 实验室试件做过 5 / 18 / 23 mm；5 mm 是其中最薄的，
#                  也接近本设备双位姿深度分辨（实测 3.86 mm FWHM）的量级。
#                  先用 5 mm 回答"看不看得见"；"最薄能看多薄"是下一轮单独扫。
#   横向 120 mm —— 深 35 mm 处的照射半宽约 31 mm，两个位姿合计覆盖 x ∈ [-46,46]。
#                  120 mm 让整个视野内都是空鼓，这是最干净的检出判定条件。
#                  空鼓横向边界的定位精度是另一轮的题（把空鼓缩小、移到视野边）。
#
# 位姿：L = -15 mm 与 +15 mm。与 S2V 同样的理由：深 35 mm 处照射半宽约 31 mm，
#       L=±27 会把目标推到照射锥边缘。
#
# 参照跑：把 VOID_X_MM 从 0 挪到 200 mm（挪出视野、仍在体模内），其余完全相同。
#         几何、材料、truth actor 一致，孔径衰减在相除时精确抵消，
#         而且可以用"参照对参照"做负对照，量出零假设下的假峰有多大。
#
# 观测量：为什么不是"找一个洞"（2026-09-10 事例级蒙卡预估的结论）
# ------------------------------------------------------------------
# 开跑之前先用 Level 2 那套蒙卡（用实测混凝土效率 2.54e-2/湮没 锚定归一化）
# 算了一遍，结果推翻了原来照搬混凝土圆柱洞的设计：
#
#   * 整体计数几乎不变：空鼓/参照 = 0.9964。空鼓移走的散射体被"光子往更深处
#     多走一段、在那里散射"补了回来。**整体计数不是可用的观测量。**
#   * 空鼓所在深度的重建计数只低 2~3%。真值剖面在那里是 100% 的洞，但单视角
#     38 mm 的深度分辨把 5 mm 的洞抹平了，而且下方的透射增强还把它填回一部分。
#     **"在空鼓深度找一个亏损"这个观测量基本失效。**
#   * 真正的信号在**空鼓下方**：45 mm 以深，空鼓组计数系统性高出 3% -> 25%，
#     渐近比值 1.242（解析预期 1.307，差别来自深度模糊）。这是透射增强：
#         ratio = exp(mu_in * dSigma) * exp(mu_out * dSigma / cos_xi)
#     其中 dSigma = 空鼓厚度 x 地仗密度 = 面密度亏损。
#     **反过来，从渐近比值可以直接解出空鼓的厚度**——这正是壁画修复要知道的量
#     （决定灌多少浆）。
#
# 所以观测量改成"重建深度剖面的比值台阶"：台阶位置给深度，台阶高度给厚度。
#
# 判据（跑之前冻结，见到 GATE 数据之后不许改）
# --------------------------------------------
#   1. 检出：45 mm 以深，空鼓/参照深度剖面比值的合并显著性 >= 5 sigma；
#            负对照（参照对参照，不同种子）< 3 sigma
#   2. 深度：比值偏离 1 的台阶位置与空鼓上表面真值之差 <= 10 mm（单位姿）
#   3. 厚度：由渐近比值反解的面密度亏损与真值之差 <= 30%
#   4. 负对照不得自己通过第 1、2 条
#   四条全过才算"能看见空鼓"；任何一条不过，如实记录不过。
#
# 分阶段跑（STAGE 环境变量）
# --------------------------
#   STAGE=a  默认。L=-15，参照 + 10 mm 空鼓，两档，约 4~6 小时。
#            10 mm 先行是因为信号 ∝ 面密度亏损：10 mm 的显著性约是 5 mm 的 3 倍，
#            蒙卡预估 >20 sigma。用它端到端验证整条链路并定标，风险最低。
#   STAGE=b  厚度扫描：5 / 3 / 2 mm，三档。**复用 stage a 的参照**——
#            参照跑与空鼓厚度无关，N 个厚度只需要 N+1 档，不是 2N 档。
#   STAGE=c  第二个位姿 L=+15（参照 + 同一厚度），做双位姿深度定位。
#
# 蒙卡预估（单位姿、200 万事例、单次散射模型）：选出事例约 5.4 万，
#   10 mm 空鼓 >20 sigma、5 mm 空鼓 7.7 sigma。真实 GATE 含多次散射，
#   对比度会被稀释，**上面的 sigma 是乐观上界**。
#   决策规则：stage a 跑完先看合并显著性。>=5 sigma 就按计划走 stage b；
#   2~5 sigma 就把每档提到 500 万；< 2 sigma 停下来重新想，别继续烧机时。
#
# 用法（务必 nohup，别放前台）
#     cd /home/vgate/beisanshe_v1/gate
#     nohup bash run_mural_void.sh > mural.out 2>&1 &
#     echo "PID: $!"
# 看进度
#     tail -f /home/vgate/beisanshe_v1/gate/mural.out
#     ls -la output/*/hits.root
# 中断后重跑：已经拷到共享盘的档会自动跳过。

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

N_PRIMARIES="${N_PRIMARIES:-2000000}"
# 注意：不同机器的共享盘挂载点不一样。新机器是 /media/sf_vgate_shared。
SHARE_OUT="${SHARE_OUT:-/media/sf_share/beisanshe_v1/gate/output}"

SOURCE_ACTIVITY_BQ=1000000
D1_RMAX_MM=200
SOURCE_THETA_MAX_DEG=45
PHANTOM_MAC="phantom_mural.mac"
PHANTOM_VOLUME="ground_coarse"
TRUTH_MAC="truth_mural.mac"
TRUTH_SUFFIX="_truth_mural"

# ---- 壁画体模几何（单位 mm）----
GROUND_FINE_MM=5
GROUND_COARSE_MM=35
SUPPORT_MM=100
GROUND_MATERIAL="MuralGround"
SUPPORT_MATERIAL="Conglomerate"
VOID_MATERIAL="Air"
VOID_THICKNESS_MM="${VOID_THICKNESS_MM:-10}"
VOID_DEPTH_MM=$(python3 -c "print(${GROUND_FINE_MM}+${GROUND_COARSE_MM}-${VOID_THICKNESS_MM})")  # 贴地仗/支撑体界面
VOID_XLEN_MM=120
VOID_YLEN_MM=120
VOID_Y_MM=0
# 各层中心 z（表面 z=0，物体在 z<0）
GROUND_FINE_CENTER_Z_MM=$(python3 -c "print(-${GROUND_FINE_MM}/2)")
GROUND_COARSE_CENTER_Z_MM=$(python3 -c "print(-(${GROUND_FINE_MM}+${GROUND_COARSE_MM}/2))")
SUPPORT_CENTER_Z_MM=$(python3 -c "print(-(${GROUND_FINE_MM}+${GROUND_COARSE_MM}+${SUPPORT_MM}/2))")
# 空鼓在粗泥层里的局部 z
VOID_LOCAL_Z_MM=$(python3 -c "print(${GROUND_FINE_MM}+${GROUND_COARSE_MM}/2-${VOID_DEPTH_MM}-${VOID_THICKNESS_MM}/2)")
# 越界检查：空鼓必须完整落在粗泥层内
python3 - <<PYCHK
f, c, d, t = ${GROUND_FINE_MM}, ${GROUND_COARSE_MM}, ${VOID_DEPTH_MM}, ${VOID_THICKNESS_MM}
assert d >= f, f"空鼓上表面 {d} mm 比细泥层底 {f} mm 还浅，会跨层"
assert d + t <= f + c, f"空鼓下表面 {d+t} mm 超过粗泥层底 {f+c} mm"
print(f"几何自检通过：空鼓 z ∈ [{-(d+t)}, {-d}] mm，粗泥层 z ∈ [{-(f+c)}, {-f}] mm")
PYCHK

# 细杆体模的占位符本轮用不到，但必须都给值
TARGET_DEPTH_MM=30
TARGET_RADIUS_MM=1
TARGET_LATERAL_MM=300
TARGET_MATERIAL="Concrete"
TARGET_THICKNESS_MM=1
TARGET_SEPARATION_MM=10

# 每档: 标签:位姿:空鼓x:种子
STAGE="${STAGE:-a}"
case "$STAGE" in
  a) JOBS="ref:-15:200:24091012 void:-15:0:24091011" ;;
  b) JOBS="void:-15:0:24091021" ;;          # 配 VOID_THICKNESS_MM=5 / 3 / 2 各跑一次
  c) JOBS="ref:15:200:24091014 void:15:0:24091013" ;;
  *) echo "STAGE 只能是 a / b / c"; exit 1 ;;
esac
N_JOBS=$(echo $JOBS | wc -w)

echo "=================================================================="
echo "M1：壁画地仗层空鼓，多位姿检出与深度定位"
echo "体模      : ${PHANTOM_MAC}"
echo "            细泥 ${GROUND_FINE_MM} + 粗泥 ${GROUND_COARSE_MM} + 支撑体 ${SUPPORT_MM} mm"
echo "空鼓      : ${VOID_THICKNESS_MM} mm 厚，深 ${VOID_DEPTH_MM} mm，横向 ${VOID_XLEN_MM}x${VOID_YLEN_MM} mm"
echo "阶段      : STAGE=${STAGE}   共 ${N_JOBS} 档"
echo "每档事件  : ${N_PRIMARIES}"
echo "共享盘输出: ${SHARE_OUT}"
echo "开始时间  : $(date '+%F %T')"
echo "=================================================================="
echo

mkdir -p "$SHARE_OUT"
JOB_N=0
for entry in $JOBS; do
  JOB_N=$((JOB_N+1))
  IFS=':' read -r KIND HEAD_X_MM VOID_X_MM RANDOM_SEED <<< "$entry"
  RUN_ID="mural_${KIND}_t${VOID_THICKNESS_MM}_L${HEAD_X_MM}_$((N_PRIMARIES/1000000))m_seed${RANDOM_SEED}"
  OUT_DIR="output/${RUN_ID}"
  OUTPUT_PREFIX="${OUT_DIR}/hits"

  if [ -d "${SHARE_OUT}/${RUN_ID}" ]; then
    echo "[跳过 ${JOB_N}/${N_JOBS}] 共享盘已存在 ${RUN_ID}"; echo; continue
  fi

  mkdir -p "$OUT_DIR"
  echo "=== [${JOB_N}/${N_JOBS}] ${KIND}  L = ${HEAD_X_MM} mm  空鼓x = ${VOID_X_MM} mm  种子 ${RANDOM_SEED}   $(date '+%T') ==="
   df -h . | tail -1

  Gate --version > "${OUT_DIR}/gate_version.txt" 2>&1 || true
  sha256sum ./*.mac ./materials/*.db > "${OUT_DIR}/macro_sha256.txt"
  {
    echo "RUN_ID=${RUN_ID}"
    echo "PURPOSE=M1 mural ground-layer void detection and depth localization"
    echo "KIND=${KIND}"
    echo "HEAD_X_MM=${HEAD_X_MM}"
    echo "PHANTOM_MAC=${PHANTOM_MAC}"
    echo "PHANTOM_VOLUME=${PHANTOM_VOLUME}"
    echo "TRUTH_MAC=${TRUTH_MAC}"
    echo "N_PRIMARIES=${N_PRIMARIES}"
    echo "RANDOM_SEED=${RANDOM_SEED}"
    echo "D1_RMAX_MM=${D1_RMAX_MM}"
    echo "SOURCE_THETA_MAX_DEG=${SOURCE_THETA_MAX_DEG}"
    echo "GROUND_FINE_MM=${GROUND_FINE_MM}"
    echo "GROUND_COARSE_MM=${GROUND_COARSE_MM}"
    echo "SUPPORT_MM=${SUPPORT_MM}"
    echo "GROUND_MATERIAL=${GROUND_MATERIAL}"
    echo "SUPPORT_MATERIAL=${SUPPORT_MATERIAL}"
    echo "VOID_MATERIAL=${VOID_MATERIAL}"
    echo "VOID_THICKNESS_MM=${VOID_THICKNESS_MM}"
    echo "VOID_DEPTH_MM=${VOID_DEPTH_MM}"
    echo "VOID_XLEN_MM=${VOID_XLEN_MM}"
    echo "VOID_YLEN_MM=${VOID_YLEN_MM}"
    echo "VOID_X_MM=${VOID_X_MM}"
    echo "VOID_Y_MM=${VOID_Y_MM}"
    echo "VOID_LOCAL_Z_MM=${VOID_LOCAL_Z_MM}"
    echo "OUTPUT_PREFIX=${OUTPUT_PREFIX}"
  } > "${OUT_DIR}/run_parameters.txt"

  Gate -a \
    "[OUTPUT_PREFIX,${OUTPUT_PREFIX}][N_PRIMARIES,${N_PRIMARIES}][SOURCE_ACTIVITY_BQ,${SOURCE_ACTIVITY_BQ}][RANDOM_SEED,${RANDOM_SEED}][D1_RMAX_MM,${D1_RMAX_MM}][SOURCE_THETA_MAX_DEG,${SOURCE_THETA_MAX_DEG}][HEAD_X_MM,${HEAD_X_MM}][PHANTOM_MAC,${PHANTOM_MAC}][PHANTOM_VOLUME,${PHANTOM_VOLUME}][TRUTH_MAC,${TRUTH_MAC}][TARGET_DEPTH_MM,${TARGET_DEPTH_MM}][TARGET_THICKNESS_MM,${TARGET_THICKNESS_MM}][TARGET_LATERAL_MM,${TARGET_LATERAL_MM}][TARGET_RADIUS_MM,${TARGET_RADIUS_MM}][TARGET_SEPARATION_MM,${TARGET_SEPARATION_MM}][TARGET_MATERIAL,${TARGET_MATERIAL}][GROUND_FINE_MM,${GROUND_FINE_MM}][GROUND_COARSE_MM,${GROUND_COARSE_MM}][SUPPORT_MM,${SUPPORT_MM}][GROUND_MATERIAL,${GROUND_MATERIAL}][SUPPORT_MATERIAL,${SUPPORT_MATERIAL}][VOID_MATERIAL,${VOID_MATERIAL}][GROUND_FINE_CENTER_Z_MM,${GROUND_FINE_CENTER_Z_MM}][GROUND_COARSE_CENTER_Z_MM,${GROUND_COARSE_CENTER_Z_MM}][SUPPORT_CENTER_Z_MM,${SUPPORT_CENTER_Z_MM}][VOID_THICKNESS_MM,${VOID_THICKNESS_MM}][VOID_XLEN_MM,${VOID_XLEN_MM}][VOID_YLEN_MM,${VOID_YLEN_MM}][VOID_X_MM,${VOID_X_MM}][VOID_Y_MM,${VOID_Y_MM}][VOID_LOCAL_Z_MM,${VOID_LOCAL_Z_MM}]" \
    main_baseline_pose.mac > "${OUT_DIR}/gate.log" 2>&1

  test -f "${OUTPUT_PREFIX}.root"
  test -f "${OUTPUT_PREFIX}${TRUTH_SUFFIX}.root"
  if grep -qi "overlap" "${OUT_DIR}/gate.log"; then
    echo "  !! 日志出现 overlap 字样，请把 gate.log 发回检查"
  fi
  echo "  GATE 完成 $(date '+%T')  用时 $(grep -oE 'Real=[0-9.]+s' "${OUT_DIR}/gate.log" | tail -1)"
  echo "  hits.root = $(stat -c %s "${OUTPUT_PREFIX}.root") 字节"

  echo "  拷到共享盘 ..."
  mkdir -p "${SHARE_OUT}/${RUN_ID}"
  cp -f "${OUT_DIR}"/* "${SHARE_OUT}/${RUN_ID}/"
  echo "  完成 $(date '+%T')"
  echo
done

echo "=================================================================="
echo "全部结束 $(date '+%F %T')"
echo "=================================================================="
