# 把 GATE 迁移到另一台机器（2026-09-10）

这个压缩包是**完整的 GATE 运行目录**（不含 output），192 KB。
解压到新机器 vGate 虚拟机里的任意目录即可，脚本用的是自己所在目录的相对路径，
不依赖 `/home/vgate` 这种固定路径。

## 一、放到哪

在新机器的虚拟机里：

```
mkdir -p ~/beisanshe_v1
cd ~/beisanshe_v1
# 把 gate_bundle_20260910.zip 放进来后
unzip gate_bundle_20260910.zip
cd gate
chmod +x *.sh
```

压缩包怎么传进虚拟机随你：远程桌面的文件传输、U 盘、网盘、
或者先放到宿主机的共享文件夹再从虚拟机里拷出来。

## 二、落地自检（一定要做，30 秒）

```
cd ~/beisanshe_v1/gate
Gate --version                      # 必须是 GATE 9.4.1 / Geant4 11.3.0
sha256sum materials/BackscatterMaterials.db phantom_mural.mac truth_mural.mac run_mural_void.sh
ls /media/sf_*                      # 确认共享盘能读（vboxsf 组已加好）
```

四个文件的 sha256 应该是（与本机一致才算传对了）：

```
522ffcd80ce03edd0142c5c886793885c4f5de649472148a1304816824ea35e8  materials/BackscatterMaterials.db
f5f73d013d2aeaeeb244a18cc66e13d8ac54b2e55e808fef84c59cf8a257512e  phantom_mural.mac
25311978f8917e96e5425aea3c38d897aaf3f0f5fe060163fd1ca28b37e5cd3e  truth_mural.mac
406c5e47b8efff266b7740944c4a8efe89642b862eaa56fbc52299888e0a9835  run_mural_void.sh
```

## 三、冒烟测试（**先跑这个，别直接开 4 小时**）

用 5 万个初级粒子跑一遍，几秒钟。目的是在烧掉 4 小时之前确认：
材料库能解析、几何没有重叠、truth actor 写得出文件、别名列表没漏项。

```
cd ~/beisanshe_v1/gate
N_PRIMARIES=50000 SHARE_OUT=/tmp/smoke_out STAGE=a bash run_mural_void.sh 2>&1 | tail -40
```

**要看到的四件事**：

1. `几何自检通过：空鼓 z ∈ [-40.0, -30.0] mm，粗泥层 z ∈ [-40, -5] mm`
2. 两档都跑完，没有报错退出
3. 每档都打印了 `hits.root = ... 字节`（不是 0）
4. **没有** `!! 日志出现 overlap 字样` 这一行

任何一条不满足，把 `output/*/gate.log` 的最后 60 行发回来，别继续。

冒烟测试跑完把它的产物清掉，免得正式跑时被"已存在就跳过"的逻辑跳过：

```
rm -rf /tmp/smoke_out output/mural_*
```

## 四、正式跑 stage a（参照 + 10 mm 空鼓，2 档，预计 4~6 小时）

```
cd ~/beisanshe_v1/gate
SHARE_OUT=/media/sf_vgate_shared/beisanshe_v1/gate/output \
  nohup bash run_mural_void.sh > mural_a.out 2>&1 &
echo "PID: $!"
```

**注意 `SHARE_OUT`**：脚本里写死的默认值是老机器的 `/media/sf_share`，
新机器挂载点是 `/media/sf_vgate_shared`，必须像上面这样覆盖。
先用 `ls /media/sf_*` 确认真实的挂载点名字。

看进度：

```
tail -f ~/beisanshe_v1/gate/mural_a.out
ls -la ~/beisanshe_v1/gate/output/*/hits.root
```

第一档跑完日志会打出真实耗时，按比例外推就知道全程要多久。

## 五、跑完要送回来的东西

每档目录（`output/mural_*/`）里有这些，全都要：

| 文件 | 大小 | 为什么要 |
|---|---|---|
| `hits.root` | 约 1 GB | 主数据 |
| `hits_truth_mural.root` | 几百 KB | 真值顶点 |
| `run_parameters.txt` | 1 KB | 参数记录 |
| `macro_sha256.txt` | 2 KB | 宏的指纹，用来证明跑的是哪一版 |
| `gate_version.txt` | 100 B | GATE 版本 |
| `gate.log` | 30 KB | 出问题时看它 |

两档合计约 2 GB。分析在 Windows 侧做（`E:\python3.12\python.exe`），
所以这些文件最终要回到那台机器的 `E:\vbgate\share\beisanshe_v1\gate\output\` 下。

如果搬 2 GB 不方便，也可以只先把 `mural_a.out`、两个 `gate.log`、
两个 `run_parameters.txt` 发回来——我先看链路对不对、耗时多少，
再决定 ROOT 要不要整个搬。

## 六、包里有什么

- `phantom_mural.mac` `truth_mural.mac` `run_mural_void.sh` —— 本轮新增
- `materials/BackscatterMaterials.db` —— 已追加壁画材料（MuralGround / Conglomerate / Air
  三组共 7 种材料，新增元素 Carbon / Nitrogen / Argon）
- 其余 `.mac` / `.sh` —— 原有的细杆、混凝土、盲测等，一并带上，
  这样新机器上可以复现以前任何一轮
